import React from 'react';
import { Navigate } from 'react-router-dom';

const getUserRole = () => {
    const storedRole = localStorage.getItem('role');
    // Convert to lowercase to ensure case-insensitive comparison
    return storedRole ? storedRole.toLowerCase() : null;
};

const isAuthenticated = () => {
    // Correctly checks for the 'token' item in localStorage
    return !!localStorage.getItem('token');
};

const PrivateRoute = ({ children, requiredRole }) => {
    const role = getUserRole(); // Role is now consistently lowercase from localStorage
    const requiredRoleLower = requiredRole ? requiredRole.toLowerCase() : null; // Ensure requiredRole is also lowercase

    // --- Add these console.logs for debugging to confirm the values ---
    console.log("PrivateRoute: isAuthenticated =", isAuthenticated());
    console.log("PrivateRoute: user role =", role);
    console.log("PrivateRoute: required role =", requiredRoleLower);
    // -------------------------------------------------------------------

    if (!isAuthenticated()) {
        console.log("PrivateRoute: Not authenticated, navigating to /login");
        return <Navigate to="/login" />;
    }

    // Now comparing two consistently lowercased strings
    if (requiredRoleLower && role !== requiredRoleLower) {
        console.log("PrivateRoute: Role mismatch, navigating to /");
        return <Navigate to="/" />; // Redirects to home if role doesn't match
    }

    console.log("PrivateRoute: All checks passed, rendering children");
    return children;
};

export default PrivateRoute;