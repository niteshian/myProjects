// src/components/ProductForm.jsx
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const ProductForm = () => {
  const navigate = useNavigate();
  const [product, setProduct] = useState({
    productName: '',
    productCategory: '',
    price: '',
    isAvailable: true,
  });

  const handleChange = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/product', product);
      alert('Product added successfully!');
      navigate('/admin-dashboard'); // ✅ Fixed route
    } catch (err) {
      console.error(err);
      alert('Failed to add product.');
    }
  };

  return (
    <div>
      <h2>Add Product</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <input
            name="productName"
            placeholder="Product Name"
            value={product.productName}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <input
            name="productCategory"
            placeholder="Category"
            value={product.productCategory}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <input
            name="price"
            placeholder="Price"
            type="number"
            value={product.price}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">Add Product</button>
      </form>
    </div>
  );
};

export default ProductForm;
