import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminDashboard = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [categoriesLoading, setCategoriesLoading] = useState(true);
  const [categoriesError, setCategoriesError] = useState(null);

  // Define your base URL for API calls and images
  const BASE_URL = 'https://localhost:7193';

  const [productForm, setProductForm] = useState({
    id: null,
    name: '',
    price: '',
    offer: '',
    discount: 0,
    categoryId: '',
    isAvailable: true,
    imageFile: null,
    currentImageUrl: '',
  });

  useEffect(() => {
    fetchProducts();
    fetchCategories();
  }, []);

  const fetchProducts = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get(`${BASE_URL}/api/product/available`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      console.log('--- fetchProducts Debug Start ---');
      console.log('Full API Response:', res);
      console.log('API Response Data (res.data):', res.data); // This log is now super helpful!

      // Your backend returns a direct array, not a .$values property.
      // So, we'll directly use res.data as the array of products.
      if (Array.isArray(res.data)) {
        setProducts(res.data);
        console.log('Products after setting state:', res.data);
        res.data.forEach((product, index) => {
          // --- Using PascalCase property names as per your API response ---
          console.log(`Product ${index} - ProductName:`, product.ProductName);
          console.log(`Product ${index} - ImageUrl:`, product.ImageUrl);
          console.log(`Product ${index} - Constructed Image SRC: ${BASE_URL}${product.ImageUrl}`);
        });
      } else {
        console.warn("API response for products was not a direct array:", res.data);
        setProducts([]);
      }
      console.log('--- fetchProducts Debug End ---');

    } catch (err) {
      console.error('Fetch products error:', err.response?.data || err.message);
      setProducts([]); // Ensure products is empty on error
    }
  };

  const fetchCategories = async () => {
    setCategoriesLoading(true);
    setCategoriesError(null);
    try {
      const res = await axios.get(`${BASE_URL}/api/category`);
      // Assuming categories also come as a direct array or .$values if using OData
      if (res.data && Array.isArray(res.data.$values)) {
        setCategories(res.data.$values);
      } else if (Array.isArray(res.data)) {
        setCategories(res.data);
      } else {
        console.warn("API response for categories was not in expected format:", res.data);
        setCategories([]);
        setCategoriesError("Unexpected category data format.");
      }
    } catch (err) {
      console.error('Fetch categories error:', err);
      setCategories([]);
      setCategoriesError("Failed to load categories. Please try again.");
    } finally {
      setCategoriesLoading(false);
    }
  };

  const handleDeleteProduct = async (id) => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`${BASE_URL}/api/product/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchProducts();
    } catch (err) {
      console.error('Delete error:', err.response?.data || err.message);
      alert('Failed to delete product.');
    }
  };

  const handleToggleAvailability = async (id, newStatus) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `${BASE_URL}/api/product/${id}/availability`,
        { isAvailable: newStatus },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      fetchProducts();
    } catch (err) {
      console.error('Toggle availability error:', err.response?.data || err.message);
      alert('Failed to update availability.');
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setProductForm((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleFileChange = (e) => {
    setProductForm((prev) => ({
      ...prev,
      imageFile: e.target.files[0],
      currentImageUrl: '', // Clear current image URL when a new file is selected
    }));
  };

  const handleEditClick = (product) => {
    setProductForm({
      id: product.ProductId,       // Using PascalCase
      name: product.ProductName,    // Using PascalCase
      price: product.Price,         // Using PascalCase
      offer: product.Offer || '',     // Using PascalCase
      discount: product.Discount || 0, // Using PascalCase
      categoryId: product.CategoryId, // Using PascalCase
      isAvailable: product.IsAvailable, // Using PascalCase
      imageFile: null,
      currentImageUrl: product.ImageUrl, // Using PascalCase
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const resetForm = () => {
    setProductForm({
      id: null,
      name: '',
      price: '',
      offer: '',
      discount: 0,
      categoryId: '',
      isAvailable: true,
      imageFile: null,
      currentImageUrl: '',
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("Product Form State (on submit):", productForm);
    console.log("Product Name being sent:", productForm.name);

    if (!productForm.name || !productForm.price || !productForm.categoryId) {
      alert('Please fill in Name, Price and Category.');
      return;
    }

    const token = localStorage.getItem('token');
    const formData = new FormData();

    // Ensure form data keys match backend expected parameters (often PascalCase too)
    if (productForm.id) {
      formData.append('ProductId', productForm.id);
    }
    formData.append('ProductName', productForm.name);
    formData.append('Price', parseFloat(productForm.price));
    formData.append('Offer', productForm.offer);
    formData.append('Discount', parseInt(productForm.discount) || 0);
    formData.append('CategoryId', parseInt(productForm.categoryId));
    formData.append('IsAvailable', productForm.isAvailable);
    if (productForm.imageFile) {
      formData.append('ImageFile', productForm.imageFile);
    }

    try {
      if (productForm.id) {
        await axios.put(`${BASE_URL}/api/product/${productForm.id}`, formData, {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data',
          },
        });
        alert('Product updated successfully!');
      } else {
        await axios.post(`${BASE_URL}/api/product`, formData, {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data',
          },
        });
        alert('Product added successfully!');
      }

      resetForm();
      fetchProducts();
    } catch (error) {
      console.error('Error submitting product:', error.response?.data || error.message);
      const errorData = error.response?.data;
      let errorMessage = 'Failed to submit product.';

      if (errorData) {
        if (errorData.ProductName && Array.isArray(errorData.ProductName)) {
          errorMessage = errorData.ProductName[0];
        } else if (errorData.errors) {
          const messages = Object.values(errorData.errors).flat();
          errorMessage = messages.join(', ');
        } else if (typeof errorData === 'string') {
          errorMessage = errorData;
        }
      }
      alert(errorMessage);
    }
  };

  return (
    <div className="admin-dashboard" style={{ padding: '20px' }}>
      <h2>Admin Dashboard</h2>

      <form onSubmit={handleSubmit} style={{ marginBottom: '30px', maxWidth: '400px' }}>
        <h3>{productForm.id ? 'Update Product' : 'Add New Product'}</h3>

        <label>Name*:</label><br />
        <input
          type="text"
          name="name"
          value={productForm.name}
          onChange={handleInputChange}
          required
          style={{ width: '100%', marginBottom: '10px' }}
        />

        <label>Image Upload:</label><br />
        <input
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          style={{ marginBottom: '10px' }}
        />

        {productForm.id && productForm.currentImageUrl && (
          <div style={{ marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '15px' }}>
            <p style={{ margin: 0, fontWeight: 'bold' }}>Current Image:</p>
            <img
              src={`${BASE_URL}${productForm.currentImageUrl}`}
              alt="Current Product"
              style={{ width: '80px', height: '80px', objectFit: 'cover', borderRadius: '4px' }}
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = `${BASE_URL}/images/default-product.jpg`;
                console.error('Failed to load current product image:', e.target.src);
              }}
            />
          </div>
        )}
        {productForm.id && (
          <p style={{ fontSize: '0.9em', color: '#666', marginTop: productForm.currentImageUrl ? '0' : '5px' }}>
            Upload a new image to replace it (optional)
          </p>
        )}

        <label>Price*:</label><br />
        <input
          type="number"
          step="0.01"
          name="price"
          value={productForm.price}
          onChange={handleInputChange}
          required
          style={{ width: '100%', marginBottom: '10px' }}
        />

        <label>Offer:</label><br />
        <input
          type="text"
          name="offer"
          value={productForm.offer}
          onChange={handleInputChange}
          placeholder="e.g., 15% Off"
          style={{ width: '100%', marginBottom: '10px' }}
        />

        <label>Discount (%):</label><br />
        <input
          type="number"
          name="discount"
          value={productForm.discount}
          onChange={handleInputChange}
          style={{ width: '100%', marginBottom: '10px' }}
          min="0"
          max="100"
        />

        <label>Category*:</label><br />
        <select
          name="categoryId"
          value={productForm.categoryId}
          onChange={handleInputChange}
          required
          style={{ width: '100%', marginBottom: '10px' }}
        >
          <option value="">-- Select Category --</option>
          {categoriesLoading ? (
            <option disabled>Loading categories...</option>
          ) : categoriesError ? (
            <option disabled>{categoriesError}</option>
          ) : (
            categories.map((cat) => (
              <option key={cat.CategoryId} value={cat.CategoryId}> {/* Assuming CategoryId and Name for categories */}
                {cat.Name}
              </option>
            ))
          )}
        </select>

        <label>
          Available:
          <input
            type="checkbox"
            name="isAvailable"
            checked={productForm.isAvailable}
            onChange={handleInputChange}
            style={{ marginLeft: '10px' }}
          />
        </label>

        <br />
        <button type="submit" style={{ marginTop: '10px' }}>
          {productForm.id ? 'Update Product' : 'Add Product'}
        </button>
        {productForm.id && (
          <button
            type="button"
            onClick={resetForm}
            style={{ marginLeft: '10px', marginTop: '10px' }}
          >
            Cancel
          </button>
        )}
      </form>

      <h3>Existing Products</h3>
      {products.length === 0 ? (
        <p>No products available.</p>
      ) : (
        products.map((product) => (
          <div
            key={product.ProductId} // Using PascalCase for key
            style={{
              border: '1px solid #ccc',
              padding: '10px',
              margin: '5px',
              display: 'flex',
              alignItems: 'center',
              gap: '20px',
            }}
          >
            {console.log(`Product Name: ${product.ProductName}`)}         {/* Using PascalCase */}
            {console.log(`Product Image URL (from API): ${product.ImageUrl}`)} {/* Using PascalCase */}
            {console.log(`Constructed Image SRC: ${BASE_URL}${product.ImageUrl}`)} {/* Using PascalCase */}

            <img
              src={`${BASE_URL}${product.ImageUrl}`} // Using PascalCase
              alt={product.ProductName} // Using PascalCase
              style={{ width: '150px', height: '150px', objectFit: 'cover', borderRadius: '8px' }}
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = `${BASE_URL}/images/default-product.jpg`;
                console.error('Failed to load product image for:', product.ProductName, 'Path:', `${BASE_URL}${product.ImageUrl}`); // Using PascalCase
              }}
            />

            <div>
              <p><strong>{product.ProductName}</strong></p>      {/* Using PascalCase */}
              <p>Category: {product.Category?.Name || 'N/A'}</p> {/* Accessing nested Category.Name */}
              <p>Price: ₹{product.Price}</p>            {/* Using PascalCase */}
              <p>Offer: {product.Offer || 'No offer'}</p>    {/* Using PascalCase */}
              <p>Discount: {product.Discount || 0}%</p>  {/* Using PascalCase */}
              <p>Status: {product.IsAvailable ? '✅ Available' : '❌ Unavailable'}</p> {/* Using PascalCase */}
              <div style={{ display: 'flex', gap: '10px' }}>
                <button onClick={() => handleEditClick(product)}>Edit</button>
                <button onClick={() => handleDeleteProduct(product.ProductId)}>Delete</button> {/* Using PascalCase */}
                <button
                  onClick={() =>
                    handleToggleAvailability(product.ProductId, !product.IsAvailable) // Using PascalCase
                  }
                >
                  {product.IsAvailable ? 'Mark Unavailable' : 'Mark Available'}
                </button>
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default AdminDashboard;