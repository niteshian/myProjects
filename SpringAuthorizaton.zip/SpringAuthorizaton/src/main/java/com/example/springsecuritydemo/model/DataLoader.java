package com.example.springsecuritydemo.model; 
import com.example.springsecuritydemo.repositories.RoleRepository;
import com.example.springsecuritydemo.repositories.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Set;
@Component
public class DataLoader implements CommandLineRunner {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    public DataLoader(UserRepository userRepository, RoleRepository roleRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("--- DataLoader: Checking and inserting initial data ---");

        // Create Roles if they don't exist
        // *** CRITICAL CHANGE: Save "USER" and "ADMIN" without "ROLE_" prefix ***
        Role userRole = roleRepository.findByName("USER").orElseGet(() -> {
            System.out.println("Creating ROLE_USER in DB (stored as 'USER')");
            return roleRepository.save(new Role("USER")); // <-- HERE
        });

        Role adminRole = roleRepository.findByName("ADMIN").orElseGet(() -> {
            System.out.println("Creating ROLE_ADMIN in DB (stored as 'ADMIN')");
            return roleRepository.save(new Role("ADMIN")); // <-- AND HERE
        });

        // Create Users if they don't exist
        if (userRepository.findByUsername("admin").isEmpty()) {
            User adminUser = new User();
            adminUser.setUsername("admin");
            adminUser.setPassword(passwordEncoder.encode("password"));
            adminUser.setRoles(Set.of(adminRole, userRole)); // Admin has both roles
            userRepository.save(adminUser);
            System.out.println("Creating admin user");
        }

        if (userRepository.findByUsername("user").isEmpty()) {
            User normalUser = new User();
            normalUser.setUsername("user");
            normalUser.setPassword(passwordEncoder.encode("password"));
            normalUser.setRoles(Set.of(userRole)); // Normal user has only USER role
            userRepository.save(normalUser);
            System.out.println("Creating normal user");
        }
        System.out.println("--- DataLoader: Initial data check and insertion complete ---");
    }
}