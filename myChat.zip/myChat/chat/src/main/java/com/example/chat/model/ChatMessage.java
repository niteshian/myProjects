package com.example.chat.model;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection = "messages")
public class ChatMessage {
	
	@Id
    private String id;
    private String sender;
    private String content;
    private MessageType type;
    private Date timestamp = new Date();
}
