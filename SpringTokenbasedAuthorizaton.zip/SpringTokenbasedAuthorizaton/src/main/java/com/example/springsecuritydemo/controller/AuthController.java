	package com.example.springsecuritydemo.controller;
	
	import org.springframework.http.ResponseEntity;
	import org.springframework.security.authentication.AuthenticationManager;
	import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
	import org.springframework.security.core.Authentication;
	import org.springframework.security.core.userdetails.UserDetails;
	import org.springframework.security.crypto.password.PasswordEncoder;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;
	
	import com.example.springsecuritydemo.authentication.AuthResponse;
	import com.example.springsecuritydemo.authentication.LoginRequest;
	import com.example.springsecuritydemo.jwt.JwtService;
	import com.example.springsecuritydemo.model.AppUser;
	import com.example.springsecuritydemo.repositories.AppUserRepository;
	import com.example.springsecuritydemo.serviceimplementation.CustomerDetails;
	
	@RestController
	@RequestMapping("/auth")
	public class AuthController {
		private final AppUserRepository appuserRepository;
		private final PasswordEncoder passwordEncoder;
		private final AuthenticationManager authenticationManager;
		private final JwtService jwtService;
		private final CustomerDetails customerDetails;
	
	    public AuthController(AppUserRepository appuserRepository, PasswordEncoder passwordEncoder,
	                          AuthenticationManager authenticationManager, JwtService jwtService,
	                          CustomerDetails customerDetails) {
	        this.appuserRepository = appuserRepository;
	        this.passwordEncoder = passwordEncoder;
	        this.authenticationManager = authenticationManager;
	        this.jwtService = jwtService;
	        this.customerDetails = customerDetails;
	    }
	    
	    @PostMapping("/register")
	        public ResponseEntity<String> register(@RequestBody AppUser user) {
	    	System.out.println("--- REALLY TESTING THIS NOW: HIT! ---"); // Add this line
	    	System.out.println("--- User trying to register: " + user.getUsername());
	        if (appuserRepository.findByUsername(user.getUsername()).isPresent()) {
	            return ResponseEntity.badRequest().body("Username is already taken!");
	        }
	        user.setPassword(passwordEncoder.encode(user.getPassword()));
	        // You might want to assign a default role here, e.g., ROLE_USER
	        // For simplicity, let's assume roles are handled elsewhere or default setup
	        appuserRepository.save(user);
	        return ResponseEntity.ok("User registered successfully!");
	    }
	    @PostMapping("/login") // <--- NEW LOGIN ENDPOINT
	    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest loginRequest) {
	        Authentication authentication = authenticationManager.authenticate(
	                new UsernamePasswordAuthenticationToken(
	                        loginRequest.getUsername(),
	                        loginRequest.getPassword()
	                )
	        );
	
	        if (authentication.isAuthenticated()) {
	            UserDetails userDetails = customerDetails.loadUserByUsername(loginRequest.getUsername());
	            String jwtToken = jwtService.generateToken(userDetails);
	            return ResponseEntity.ok(AuthResponse.builder().token(jwtToken).message("Login successful").build());
	        } else {
	            return ResponseEntity.status(401).body(AuthResponse.builder().message("Invalid credentials").build());
	        }
	    }
	}
		
