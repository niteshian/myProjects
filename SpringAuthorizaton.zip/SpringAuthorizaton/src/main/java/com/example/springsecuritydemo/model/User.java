			package com.example.springsecuritydemo.model;
			import java.util.HashSet;
			import java.util.Set;
			
			import jakarta.persistence.Column;
			import jakarta.persistence.Entity;
			import jakarta.persistence.FetchType;
			import jakarta.persistence.GeneratedValue;
			import jakarta.persistence.GenerationType;
			import jakarta.persistence.Id;
		import jakarta.persistence.JoinColumn;
		import jakarta.persistence.JoinTable;
			import jakarta.persistence.ManyToMany;
			import jakarta.persistence.Table;
			
			@Entity
			@Table(name="app_user")
			public class User {
			@Id
			@GeneratedValue(strategy=GenerationType.IDENTITY)
			private Long id;
			@Column(unique=true,nullable=false)
			private String username;
			@Column(nullable=false)
			private String password;
			@ManyToMany(fetch = FetchType.EAGER) // Fetch roles eagerly when user is loaded
		    @JoinTable(
		        name = "user_roles",
		        joinColumns = @JoinColumn(name = "user_id"),
		        inverseJoinColumns = @JoinColumn(name = "role_id"))
			private Set<Role>roles=new HashSet<>();
			
			
			public User() {}
		
			public User(String username, String password, Set<Role> roles) {
		        this.username = username;
		        this.password = password;
		        // Ensure roles are correctly set and not null
		        if (roles != null) {
		            this.roles = new HashSet<>(roles); // Copy to ensure it's a new mutable set
		        } else {
		            this.roles = new HashSet<>();
		        }
		    }
			public Long getId() {
				return id;}
			public void setId(Long id) {
				this.id = id;
			}
			public String getUsername() {
		        return username;
		    }
		
		    public void setUsername(String username) {
		        this.username = username;
		    }
		
		    public String getPassword() {
		        return password;
		    }
		
		    public void setPassword(String password) {
		        this.password = password;
		    }
		
		    public Set<Role> getRoles() {
		        return roles;
		    }
		
		    public void setRoles(Set<Role> roles) {
		        this.roles = roles;
		    }
		
		    public void addRole(Role role) {
		        this.roles.add(role);
		    }
		}
			
			
			
				
			
			
