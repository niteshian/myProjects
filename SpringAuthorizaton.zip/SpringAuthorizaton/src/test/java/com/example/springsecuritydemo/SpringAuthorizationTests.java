package com.example.springsecuritydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAuthorizationTests {

	@Test
	void contextLoads() {
	}

}
