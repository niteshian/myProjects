// App.jsx
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './PagesTemp/Home';
import Login from './PagesTemp/Login';
import Register from './PagesTemp/Register';
import AdminDashboard from './PagesTemp/AdminDashboard';
import CustomerDashboard from './PagesTemp/CustomerDashboard';
import Navbar from './PagesTemp/Navbar';
import PrivateRoute from './Routes/PrivateRoute';
import ProductForm from './Components/ProductForm';
import CheckoutPage from './Components/CheckoutPage'; // Correct import for default export
import OrderHistoryPage from './Components/OrderHistoryPage';
import OrderConfirmationPage from './Components/OrderConfirmationPage';
import CartPage from './Components/CartPage';
// src/Components/CheckoutPage.jsx
// Add .jsx extension

function App() {
    return (
        <>
            <Navbar />
            <div className="container mt-4">
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/checkout" element={<CheckoutPage />} />
                    <Route path="/order-history" element={<OrderHistoryPage/>}/>
                    <Route path="/order-confirmation/:orderId" element={<OrderConfirmationPage/>}/>
                    <Route path="/cart" element={<CartPage />} />

                    <Route
                        path="/admin-dashboard"
                        element={
                            <PrivateRoute requiredRole="admin">
                                <AdminDashboard />
                            </PrivateRoute>
                        }
                    />

                    <Route
                        path="/admin/add-product"
                        element={
                            <PrivateRoute requiredRole="admin">
                                <ProductForm />
                            </PrivateRoute>
                        }
                    />

                    <Route
                        path="/customer-dashboard"
                        element={
                            <PrivateRoute requiredRole="customer">
                                <CustomerDashboard />
                            </PrivateRoute>
                        }
                    />
                </Routes>
            </div>
        </>
    );
}

export default App;