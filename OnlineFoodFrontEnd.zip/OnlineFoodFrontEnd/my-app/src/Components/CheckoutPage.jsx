import React, { useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api.jsx';
import { CartContext } from '../context/CartContext.jsx';

const CheckoutPage = () => {
    const { cart, clearCart } = useContext(CartContext);
    const navigate = useNavigate();

    const [shippingInfo, setShippingInfo] = useState({
        fullName: '',
        addressLine1: '',
        addressLine2: '',
        city: '',
        state: '',
        zipCode: '',
        phone: '',
        paymentMethod: 'CashOnDelivery'
    });

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [formErrors, setFormErrors] = useState({});

    // Effect to check if cart is empty on component mount
    useEffect(() => {
        if (cart.length === 0) {
            alert("Your cart is empty. Please add items before checking out.");
            navigate('/customer-dashboard');
        }
        console.log("Cart contents on CheckoutPage load:", cart);
    }, [cart, navigate]); // Depend on cart and navigate (stable)

    // Helper function to calculate item price after discount
    const calculateItemPriceAfterDiscount = (item) => {
        // Destructure properties for cleaner access
        const { Price, Discount } = item;
        // Ensure Discount is a number, default to 0 if not
        const discount = typeof Discount === 'number' ? Discount : 0;
        if (discount > 0) {
            return Price - (Price * discount / 100);
        }
        return Price;
    };

    // Helper function to calculate the total amount of the cart
    const calculateCartTotal = () => {
        console.log("Starting calculateCartTotal. Current cart:", cart);

        // Use reduce to sum up the total of all items
        return cart.reduce((total, item) => {
            const finalPrice = calculateItemPriceAfterDiscount(item);
            return total + (finalPrice * item.quantity);
        }, 0); // Initialize total to 0
    };

    // Handle input changes for shipping information
    const handleChange = (e) => {
        const { name, value } = e.target;
        setShippingInfo({
            ...shippingInfo,
            [name]: value
        });
        // Clear specific error message when input changes
        setFormErrors(prevErrors => ({
            ...prevErrors,
            [name]: ''
        }));
    };

    // Validate form fields
    const validateForm = () => {
        const errors = {};
        if (!shippingInfo.fullName.trim()) errors.fullName = 'Full Name is required.';
        if (!shippingInfo.addressLine1.trim()) errors.addressLine1 = 'Address Line 1 is required.';
        if (!shippingInfo.city.trim()) errors.city = 'City is required.';
        if (!shippingInfo.state.trim()) errors.state = 'State is required.';
        if (!shippingInfo.zipCode.trim()) errors.zipCode = 'Zip Code is required.';
        // Basic phone number validation (e.g., checks if it's not empty)
        if (!shippingInfo.phone.trim()) errors.phone = 'Phone Number is required.';

        setFormErrors(errors);
        // Return true if no errors, false otherwise
        return Object.keys(errors).length === 0;
    };

    // Handle placing the order
    const handlePlaceOrder = async (e) => {
        e.preventDefault(); // Prevent default form submission

        // Validate form before proceeding
        if (!validateForm()) {
            alert('Please fill in all required fields.');
            return;
        }

        setLoading(true); // Set loading state to true
        setError(null); // Clear any previous errors

        try {
            const token = localStorage.getItem('token');
            console.log("Token from localStorage:", token);

            // Redirect to login if no token is found
            if (!token) {
                console.error("No token found in localStorage. User not logged in.");
                alert("Please log in to place an order.");
                navigate('/login');
                return;
            }

            let customerId; // Variable to hold the extracted customer ID

            try {
                // Decode JWT token to get customer ID
                const base64Url = token.split('.')[1];
                if (!base64Url) {
                    throw new Error("Invalid token format: missing payload part.");
                }
                const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
                const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
                    return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
                }).join(''));

                const decodedToken = JSON.parse(jsonPayload);
                console.log("Decoded Token Payload:", decodedToken);

                // Prioritize common claims for customer ID (nameid, sub, id, userId, customer_id)
                const customerIdClaim = decodedToken.nameid || decodedToken.sub || decodedToken.id || decodedToken.userId || decodedToken.customer_id;
                
                if (!customerIdClaim) { // Check if claim is truly empty or undefined/null
                    throw new Error("Customer ID claim (nameid, sub, id, userId, or customer_id) not found or is empty in token payload.");
                }

                // Assign the customerId as a string (GUID) directly
                customerId = customerIdClaim; 

                console.log("Extracted Customer ID (GUID string):", customerId);

            } catch (decodeError) {
                console.error("Error decoding token or extracting user ID:", decodeError);
                setError("Authentication error: Could not verify your login session or invalid user ID. Please log in again. Details: " + decodeError.message);
                alert("Authentication error: Could not verify your login session or invalid user ID. Please log in again. Details: " + decodeError.message);
                navigate('/login');
                return;
            }

            // Construct the full shipping address string
            const fullAddress = `${shippingInfo.fullName}, ${shippingInfo.addressLine1}${shippingInfo.addressLine2 ? ', ' + shippingInfo.addressLine2 : ''}, ${shippingInfo.city}, ${shippingInfo.state} - ${shippingInfo.zipCode}, Phone: ${shippingInfo.phone}`;
            
            console.log("Cart items before forming orderItems payload:", cart);
            // Map cart items to the required order item structure for the API
            const orderItems = cart.map(item => ({
                productId: item.ProductId, // Assuming ProductId is the correct property name
                quantity: item.quantity,
                priceAtOrder: calculateItemPriceAfterDiscount(item)
            }));
            console.log("Order items payload structure:", orderItems);

            // Prepare the full order data payload
            const orderData = {
                customerId: customerId, // Send GUID string
                shippingAddress: fullAddress,
                paymentMethod: shippingInfo.paymentMethod,
                items: orderItems,
                totalAmount: calculateCartTotal()
            };

            console.log("Attempting to send order request. Payload to API:", orderData);

            // Send the order request to the backend API
            const response = await api.post('/order', orderData);

            // Handle successful order placement
            if (response.status === 200 || response.status === 201) {
                console.log("✅ Order placed successfully:", response.data);
                alert("Order placed successfully!");
                clearCart(); // Clear the cart after successful order

                // Navigate to order confirmation page or order history
                if (response.data && response.data.orderId) {
                    navigate(`/order-confirmation/${response.data.orderId}`);
                } else {
                    navigate('/order-history');
                }
            } else {
                // Handle non-2xx responses
                setError(`Order placement failed: ${response.data?.message || 'Unknown error'}`);
            }

        } catch (err) {
            // Handle API call errors
            console.error("Error placing order:", err.response?.data || err.message);
            setError(`Failed to place order: ${err.response?.data?.message || err.message}`);
            if (err.response?.status === 401) {
                alert("You are not authorized. Please log in again.");
                navigate('/login');
            } else if (err.response?.status === 400) {
                alert(`Invalid order data: ${err.response.data?.message || 'Please check your details.'}`);
            }
        } finally {
            setLoading(false); // Always set loading to false after attempt
        }   
    };

    return (
        <div className="bg-light py-5">
            <div className="container custom-container mx-auto px-3">
                <h2 className="text-center mb-5 text-dark fw-bold display-5">
                    Secure Checkout
                </h2>

                <div className="row g-4 justify-content-center">
                    <div className="col-lg-7 order-lg-1">
                        <div className="card shadow-lg border-0 rounded-4 overflow-hidden">
                            <div className="card-header bg-dark text-white p-3 rounded-top-4">
                                <h4 className="mb-0">Shipping & Billing Details</h4>
                            </div>
                            <div className="card-body p-4">
                                <form onSubmit={handlePlaceOrder}>
                                    <div className="row g-3">
                                        <div className="col-12">
                                            <label htmlFor="fullName" className="form-label">Full Name</label>
                                            <input
                                                type="text"
                                                className={`form-control form-control-lg ${formErrors.fullName ? 'is-invalid' : ''}`}
                                                id="fullName"
                                                name="fullName"
                                                value={shippingInfo.fullName}
                                                onChange={handleChange}
                                                placeholder="John Doe"
                                                required
                                            />
                                            {formErrors.fullName && <div className="invalid-feedback">{formErrors.fullName}</div>}
                                        </div>

                                        <div className="col-12">
                                            <label htmlFor="addressLine1" className="form-label">Address Line 1</label>
                                            <input
                                                type="text"
                                                className={`form-control form-control-lg ${formErrors.addressLine1 ? 'is-invalid' : ''}`}
                                                id="addressLine1"
                                                name="addressLine1"
                                                value={shippingInfo.addressLine1}
                                                onChange={handleChange}
                                                placeholder="House No., Building Name, Street"
                                                required
                                            />
                                            {formErrors.addressLine1 && <div className="invalid-feedback">{formErrors.addressLine1}</div>}
                                        </div>

                                        <div className="col-12">
                                            <label htmlFor="addressLine2" className="form-label">Address Line 2 <span className="text-muted small">(Optional)</span></label>
                                            <input
                                                type="text"
                                                className="form-control form-control-lg"
                                                id="addressLine2"
                                                name="addressLine2"
                                                value={shippingInfo.addressLine2}
                                                onChange={handleChange}
                                                placeholder="Apartment, suite, unit etc."
                                            />
                                        </div>

                                        <div className="col-md-6">
                                            <label htmlFor="city" className="form-label">City</label>
                                            <input
                                                type="text"
                                                className={`form-control form-control-lg ${formErrors.city ? 'is-invalid' : ''}`}
                                                id="city"
                                                name="city"
                                                value={shippingInfo.city}
                                                onChange={handleChange}
                                                placeholder="Mumbai"
                                                required
                                            />
                                            {formErrors.city && <div className="invalid-feedback">{formErrors.city}</div>}
                                        </div>

                                        <div className="col-md-6">
                                            <label htmlFor="state" className="form-label">State</label>
                                            <input
                                                type="text"
                                                className={`form-control form-control-lg ${formErrors.state ? 'is-invalid' : ''}`}
                                                id="state"
                                                name="state"
                                                value={shippingInfo.state}
                                                onChange={handleChange}
                                                placeholder="Maharashtra"
                                                required
                                            />
                                            {formErrors.state && <div className="invalid-feedback">{formErrors.state}</div>}
                                        </div>

                                        <div className="col-md-6">
                                            <label htmlFor="zipCode" className="form-label">Zip Code</label>
                                            <input
                                                type="text"
                                                className={`form-control form-control-lg ${formErrors.zipCode ? 'is-invalid' : ''}`}
                                                id="zipCode"
                                                name="zipCode"
                                                value={shippingInfo.zipCode}
                                                onChange={handleChange}
                                                placeholder="400001"
                                                required
                                            />
                                            {formErrors.zipCode && <div className="invalid-feedback">{formErrors.zipCode}</div>}
                                        </div>

                                        <div className="col-md-6">
                                            <label htmlFor="phone" className="form-label">Phone Number</label>
                                            <input
                                                type="tel" // Use type="tel" for phone numbers
                                                className={`form-control form-control-lg ${formErrors.phone ? 'is-invalid' : ''}`}
                                                id="phone"
                                                name="phone"
                                                value={shippingInfo.phone}
                                                onChange={handleChange}
                                                placeholder="e.g., 9876543210"
                                                required
                                            />
                                            {formErrors.phone && <div className="invalid-feedback">{formErrors.phone}</div>}
                                        </div>
                                    </div>

                                    <hr className="my-5" />

                                    <h4 className="mb-4 text-center">Select Payment Method</h4>
                                    <div className="d-flex flex-column gap-3 my-3">
                                        <div className="form-check form-check-inline">
                                            <input
                                                id="cashOnDelivery"
                                                name="paymentMethod"
                                                type="radio"
                                                className="form-check-input"
                                                value="CashOnDelivery"
                                                checked={shippingInfo.paymentMethod === 'CashOnDelivery'}
                                                onChange={handleChange}
                                                required
                                            />
                                            <label className="form-check-label" htmlFor="cashOnDelivery">Cash on Delivery</label>
                                        </div>
                                        <div className="form-check form-check-inline">
                                            <input
                                                id="creditCard"
                                                name="paymentMethod"
                                                type="radio"
                                                className="form-check-input"
                                                value="CreditCard"
                                                checked={shippingInfo.paymentMethod === 'CreditCard'}
                                                onChange={handleChange}
                                                required
                                            />
                                            <label className="form-check-label" htmlFor="creditCard">Credit Card</label>
                                        </div>
                                        <div className="form-check form-check-inline">
                                            <input
                                                id="paypal"
                                                name="paymentMethod"
                                                type="radio"
                                                className="form-check-input"
                                                value="PayPal"
                                                checked={shippingInfo.paymentMethod === 'PayPal'}
                                                onChange={handleChange}
                                                required
                                            />
                                            <label className="form-check-label" htmlFor="paypal">PayPal</label>
                                        </div>
                                    </div>

                                    <hr className="my-5" />

                                    {error && <div className="alert alert-danger text-center mb-4">{error}</div>}

                                    <button
                                        className="w-100 btn btn-success btn-lg mt-3 fw-bold py-3"
                                        type="submit"
                                        disabled={loading || cart.length === 0}
                                    >
                                        {loading ? 'Placing Order...' : 'Place Order'}
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-5 order-lg-2 mb-4">
                        <div className="card shadow-lg border-0 rounded-4 h-100 overflow-hidden">
                            <div className="card-header bg-dark text-white p-3 rounded-top-4">
                                <h4 className="mb-0">Your Order Summary</h4>
                            </div>
                            <div className="card-body d-flex flex-column p-4">
                                <ul className="list-group list-group-flush mb-auto">
                                    {cart.length === 0 ? (
                                        <li className="list-group-item text-center text-muted py-4">
                                            Your cart is empty. Please add items to checkout.
                                        </li>
                                    ) : (
                                        cart.map(item => (
                                            // Using item.ProductId as a unique key for list rendering
                                            <li className="list-group-item d-flex justify-content-between align-items-center lh-base py-3" key={item.ProductId}>
                                                <div>
                                                    {/* Display product name, prioritizing productName over name if both exist */}
                                                    <h6 className="my-0 text-dark">{item.productName || item.name}</h6>
                                                    <small className="text-muted">Quantity: {item.quantity}</small>
                                                </div>
                                                <span className="fw-bold text-success">₹{(calculateItemPriceAfterDiscount(item) * item.quantity).toFixed(2)}</span>
                                            </li>
                                        ))
                                    )}
                                </ul>
                                <div className="list-group-item d-flex justify-content-between align-items-center bg-light fw-bold py-3 mt-4 border-top rounded-bottom-4">
                                    <span className="h5 mb-0">Total Amount (INR)</span>
                                    <strong className="h5 mb-0 text-success">₹{calculateCartTotal().toFixed(2)}</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CheckoutPage;