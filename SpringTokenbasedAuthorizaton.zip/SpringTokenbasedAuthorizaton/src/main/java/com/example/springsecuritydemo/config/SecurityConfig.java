package com.example.springsecuritydemo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

// IMPORTANT: Ensure this import is NOT commented out in your actual file
// import org.springframework.security.web.header.frameoptions.XFrameOptionsHeaderWriter;

import com.example.springsecuritydemo.jwt.JwtAuthenticationFilter;
import com.example.springsecuritydemo.serviceimplementation.CustomerDetails;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
    private final CustomerDetails customerDetails;
    private final JwtAuthenticationFilter jwtAuthFilter;

    public SecurityConfig(CustomerDetails customerDetails, JwtAuthenticationFilter jwtAuthFilter) {
        this.customerDetails = customerDetails;
        this.jwtAuthFilter = jwtAuthFilter;
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(customerDetails);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            // 1. CSRF configuration for H2 Console
            
            // 2. IMPORTANT: Allow H2 Console to load in a frame
            .headers(headers -> headers
                .frameOptions(frameOptions -> frameOptions.sameOrigin()))
            .authorizeHttpRequests(authorize -> authorize
                // Allow public access to auth endpoints (register, login)
                .requestMatchers(AntPathRequestMatcher.antMatcher("/auth/**")).permitAll()
                // Allow H2 console access
                .requestMatchers(AntPathRequestMatcher.antMatcher("/h2-console/**")).permitAll()
                // Allow public access to root and /public
                .requestMatchers("/", "/public").permitAll()
                .requestMatchers("/user-only").hasAnyRole("USER", "ADMIN")
                .requestMatchers("/admin-only").hasRole("ADMIN")
                .requestMatchers("/secured").authenticated()
                .anyRequest().authenticated() // All other requests require authentication
            )
            // Configure session management to be STATELESS for JWT
            .sessionManagement(session -> session
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )
            // Set custom authentication provider
            .authenticationProvider(authenticationProvider())
            // Add the JWT filter before the Spring Security UsernamePasswordAuthenticationFilter
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)
            // Disable default form login and http basic since we're using JWT
            .formLogin(form -> form.disable()) // Explicitly disable form login
            .httpBasic(httpBasic -> httpBasic.disable()) // Explicitly disable http basic
            // Add logout configuration for completeness
            .logout(logout -> logout
                .permitAll() // Allow logout for all
                .logoutUrl("/auth/logout") // Define logout URL
                .logoutSuccessUrl("/")
                .deleteCookies("JSESSIONID") // Delete session cookie if any, though stateless
            );
        return http.build();
    }
}