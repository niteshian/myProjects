
package com.example.springsecuritydemo.serviceimplementation;

import com.example.springsecuritydemo.model.AppUser; // JPA entity
import com.example.springsecuritydemo.repositories.AppUserRepository; // repository
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.core.userdetails.User; // Spring Security's User class
import org.springframework.stereotype.Service;

import java.util.Collections; // For simple authorities if AppUser doesn't have them yet

@Service
public class CustomerDetails implements UserDetailsService {

    private final AppUserRepository appUserRepository;

    public CustomerDetails(AppUserRepository appUserRepository){
        this.appUserRepository = appUserRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AppUser appUser = appUserRepository.findByUsername(username) // You'll need this method in your repo
            .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));

        // Convert your AppUser entity to Spring Security's UserDetails
        // You might need to map roles/authorities from AppUser here
        return new User(appUser.getUsername(), appUser.getPassword(), Collections.emptyList()); // Replace with actual authorities
        // Or if AppUser implements UserDetails directly:
        // return appUser;
    }
}