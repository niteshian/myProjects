// src/context/CartContext.jsx

import React, { createContext, useState, useEffect } from 'react';

// 1. Create the Context object
// This is what components will 'useContext' to access cart data and functions.
export const CartContext = createContext();

// 2. Create the Provider component
// This component will wrap parts of your application (typically the whole App)
// to provide the cart state and methods to all its descendants.
export const CartProvider = ({ children }) => {
    // Initialize cart state, trying to load from localStorage first
    const [cart, setCart] = useState(() => {
        try {
            const localCart = localStorage.getItem('cart');
            return localCart ? JSON.parse(localCart) : [];
        } catch (error) {
            console.error("Failed to parse cart from localStorage:", error);
            return []; // Return empty array on error
        }
    });

    // Use useEffect to save cart to localStorage whenever it changes
    useEffect(() => {
        try {
            localStorage.setItem('cart', JSON.stringify(cart));
        } catch (error) {
            console.error("Failed to save cart to localStorage:", error);
        }
    }, [cart]); // Dependency array: run this effect whenever 'cart' state changes

    // Function to add an item to the cart
    const addToCart = (productToAdd) => {
        setCart(prevCart => {
            // Check if the product already exists in the cart
            const existingItemIndex = prevCart.findIndex(item => item.productId === productToAdd.productId);

            if (existingItemIndex > -1) {
                // If item exists, update its quantity
                const updatedCart = [...prevCart];
                updatedCart[existingItemIndex] = {
                    ...updatedCart[existingItemIndex],
                    quantity: updatedCart[existingItemIndex].quantity + (productToAdd.quantity || 1) // Add quantity, default to 1
                };
                return updatedCart;
            } else {
                // If item does not exist, add it to the cart
                return [...prevCart, { ...productToAdd, quantity: productToAdd.quantity || 1 }]; // Ensure quantity is set, default to 1
            }
        });
    };

    // Function to remove an item from the cart
    const removeFromCart = (productId) => {
        setCart(prevCart => prevCart.filter(item => item.productId !== productId));
    };

    // Function to update the quantity of an item in the cart
    const updateQuantity = (productId, newQuantity) => {
        setCart(prevCart => {
            if (newQuantity <= 0) {
                // If quantity is 0 or less, remove the item
                return prevCart.filter(item => item.productId !== productId);
            }
            return prevCart.map(item =>
                item.productId === productId
                    ? { ...item, quantity: newQuantity }
                    : item
            );
        });
    };


    // Function to clear the entire cart
    const clearCart = () => {
        setCart([]);
    };

    // The value object that will be provided to all consuming components
    const contextValue = {
        cart,
        addToCart,
        removeFromCart,
        updateQuantity, // Added updateQuantity
        clearCart,
    };

    return (
        <CartContext.Provider value={contextValue}>
            {children}
        </CartContext.Provider>
    );
};