﻿namespace OnlineFood.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    namespace YourFoodOrderingSystem.Backend.Models
    {
        public class OrderItem
        {
            [Key]
            public int OrderItemId { get; set; }

            // Foreign key to Order
            public Guid OrderId { get; set; }
            public Order Order { get; set; } = null!; // Required navigation property

            // Foreign key to Product
            public int ProductId { get; set; }
            // public Product Product { get; set; } = null!; // Uncomment if you have Product model

            [Required]
            public int Quantity { get; set; }

            // Store price and discount at the time of order for historical accuracy
            [Required]
            [Column(TypeName = "decimal(18, 2)")]
            public decimal UnitPriceAtOrder { get; set; } // Price of product when ordered

            [Required]
            [Column(TypeName = "decimal(5, 2)")] // e.g., for 15.00% discount
            public decimal DiscountAppliedAtOrder { get; set; } // Discount % at the time of order
        }
    }
}
