﻿namespace OnlineFood.Dtos
{
    public class ProductAvailabilityDto
    {
        public bool IsAvailable { get; set; }



    }
}
