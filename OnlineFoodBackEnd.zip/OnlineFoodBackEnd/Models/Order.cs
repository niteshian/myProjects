﻿namespace OnlineFood.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    namespace YourFoodOrderingSystem.Backend.Models
    {
        public class Order
        {
            [Key]
            public Guid OrderId { get; set; } // Use Guid for unique order IDs

            // Foreign key to your Customer/User table (assuming you have one)
            // Adjust type if your Customer ID is int or long
            public Guid CustomerId { get; set; }
            // public Customer Customer { get; set; } // Uncomment if you have Customer model

            [Required]
            public DateTime OrderDate { get; set; } = DateTime.UtcNow; // Set default to current UTC time

            [Required]
            [StringLength(500)] // Adjust max length as needed
            public string ShippingAddress { get; set; }

            [Required]
            [Column(TypeName = "decimal(18, 2)")] // Ensure correct precision for currency
            public decimal TotalAmount { get; set; }

            [Required]
            [StringLength(50)] // e.g., "COD", "Online"
            public string PaymentMethod { get; set; }

            [Required]
            [StringLength(50)] // e.g., "Pending", "Confirmed", "Shipped", "Delivered", "Cancelled"
            public string OrderStatus { get; set; } = "Pending"; // Default status

            // For future online payments (nullable)
            [StringLength(255)]
            public string? PaymentGatewayOrderId { get; set; } // e.g., Stripe PaymentIntent ID

            // Navigation property for order items
            public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
        }
    }
}
