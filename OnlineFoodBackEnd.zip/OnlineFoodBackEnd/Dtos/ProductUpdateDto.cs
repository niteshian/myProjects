﻿public class ProductUpdateDto
{
    public int ProductId { get; set; }
    public string ProductName { get; set; }
    public decimal Price { get; set; }
    public bool IsAvailable { get; set; }
    public string Offer { get; set; }
    public int Discount { get; set; }
    public int CategoryId { get; set; }

    public IFormFile? ImageFile { get; set; } // For new upload
    public string? ExistingImageName { get; set; } // For reusing existing
}
