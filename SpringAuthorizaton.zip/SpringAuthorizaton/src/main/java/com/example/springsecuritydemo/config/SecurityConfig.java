package com.example.springsecuritydemo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher; // <--- ADD THIS IMPORT! // <--- ADD THIS IMPORT!

import com.example.springsecuritydemo.serviceimplementation.CustomerDetails;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
    private final CustomerDetails customerDetails;

    public SecurityConfig(CustomerDetails customerDetails) {
        this.customerDetails = customerDetails;
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
    	
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(customerDetails);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // 1. CSRF configuration for H2 Console
            .csrf(csrf -> csrf
                .ignoringRequestMatchers(AntPathRequestMatcher.antMatcher("/h2-console/**"))
            )
            // 2. IMPORTANT: Allow H2 Console to load in a frame
            .headers(headers -> headers
                .frameOptions(frameOptions -> frameOptions.sameOrigin())) // <--- CHANGED TO .sameOrigin()
                                                                         // .disable() would prevent it from showing!
            .authorizeHttpRequests(authorize -> authorize
                // Allow H2 console access
                .requestMatchers(AntPathRequestMatcher.antMatcher("/h2-console/**")).permitAll()
                // Allow public access to root and /public
                .requestMatchers("/", "/public").permitAll()
                // Corrected: Use hasAnyRole if both USER and ADMIN can access /user-only
                .requestMatchers("/user-only").hasAnyRole("USER", "ADMIN")
                // Keep distinct for /admin-only
                .requestMatchers("/admin-only").hasRole("ADMIN")
                .requestMatchers("/secured").authenticated() // Assuming this is an endpoint that requires any authentication
                .anyRequest().authenticated() // All other requests require authentication
            )
            .formLogin(form -> form.permitAll())
            .httpBasic(httpBasic -> {})
            // Add logout configuration for completeness
            .logout(logout -> logout
                .permitAll()
                .logoutSuccessUrl("/") // Redirect to home after logout
            );
        return http.build();
    }
}