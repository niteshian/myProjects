import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const OrderHistoryPage = () => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    // Use the same API instance you configured in api.jsx for consistency and interceptor benefits
    // import api from '../api.jsx'; // <-- If you want to use your custom axios instance
    // const BASE_URL = 'https://localhost:7193'; // This should ideally come from your api.jsx or an env variable

    // For now, I'll keep the BASE_URL as you had it, but recommend using the 'api' instance.
    // If you used the `api` instance from `api.jsx`, you wouldn't need this BASE_URL here.
    const BASE_URL = 'https://localhost:7193'; // Ensure this is your correct backend URL

    useEffect(() => {
        const fetchOrders = async () => {
            try {
                setLoading(true);
                setError(null);

                const token = localStorage.getItem('token');

                if (!token) {
                    setError("You are not logged in. Please log in to view your orders.");
                    // Use a short delay before navigating to allow the error message to be seen
                    setTimeout(() => navigate('/login'), 1500); 
                    return;
                }

                // IMPORTANT: Use the `api` instance from api.jsx if possible, 
                // as it automatically adds the Authorization header.
                // If you use `axios.get` directly, you MUST include the headers as you have.
                const response = await axios.get(`${BASE_URL}/api/order/customer-orders`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                
                // Ensure response.data is an array. If backend returns an object with a list, adapt here.
                // For example, if it returns { data: [...] }, use response.data.data
                setOrders(Array.isArray(response.data) ? response.data : []); 
                console.log("Fetched orders:", response.data); // Log response to inspect structure

            } catch (err) {
                console.error('Error fetching orders:', err.response?.data || err.message);
                if (err.response?.status === 404) {
                    // This often means no orders found for the user, not a page not found.
                    setError("You haven't placed any orders yet or the API endpoint is not found.");
                    setOrders([]); // Ensure orders state is empty if 404 means no orders
                } else if (err.response?.status === 401 || err.response?.status === 403) {
                    setError("Your session has expired or you are not authorized. Please log in again.");
                    localStorage.removeItem('token');
                    setTimeout(() => navigate('/login'), 1500);
                } else {
                    setError('Failed to load orders. Please try again.');
                }
            } finally {
                setLoading(false);
            }
        };

        fetchOrders();
    }, [navigate]); // navigate is a stable function provided by react-router-dom, but good practice to include

    if (loading) {
        return <div style={{ textAlign: 'center', padding: '50px' }}>Loading your orders...</div>;
    }

    if (error) {
        return <div style={{ textAlign: 'center', padding: '50px', color: 'red' }}>Error: {error}</div>;
    }

    const getStatusColor = (status) => {
        switch (status) {
            case 'Pending': return '#ffc107'; // Yellow
            case 'Confirmed': return '#17a2b8'; // Teal
            case 'Shipped': return '#007bff'; // Blue
            case 'Delivered': return '#28a745'; // Green
            case 'Cancelled': return '#dc3545'; // Red
            default: return '#6c757d'; // Grey
        }
    };

    return (
        <div style={{ padding: '20px', maxWidth: '1000px', margin: 'auto' }}>
            <h2 style={{ textAlign: 'center', marginBottom: '30px' }}>My Orders</h2>

            {orders.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '30px', border: '1px dashed #ccc', borderRadius: '8px', color: '#666' }}>
                    <p>You currently have no orders.</p>
                    <button
                        onClick={() => navigate('/customer-dashboard')}
                        style={{ background: 'none', border: 'none', color: '#007bff', textDecoration: 'underline', cursor: 'pointer', marginTop: '10px' }}
                    >
                        Start shopping now!
                    </button>
                </div>
            ) : (
                <div className="order-list" style={{ display: 'grid', gap: '25px' }}>
                    {orders.map(order => (
                        <div key={order.OrderId} style={{
                            border: '1px solid #e0e0e0',
                            borderRadius: '10px',
                            padding: '20px',
                            backgroundColor: '#fff',
                            boxShadow: '0 4px 8px rgba(0,0,0,0.05)'
                        }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px', borderBottom: '1px solid #eee', paddingBottom: '10px' }}>
                                <h3>Order ID: <span style={{ color: '#007bff' }}>{order.OrderId?.substring(0, 8)}...</span></h3>
                                <span style={{ fontWeight: 'bold', fontSize: '1.1em', color: '#555' }}>
                                    Date: {order.OrderDate ? new Date(order.OrderDate).toLocaleDateString() : 'N/A'}
                                </span>
                            </div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                                {/* Use optional chaining and nullish coalescing for safety */}
                                <p style={{ margin: 0 }}>Total Amount: <strong style={{ color: '#28a745' }}>₹{(Number(order.TotalAmount ?? 0)).toFixed(2)}</strong></p>
                                <p style={{ margin: 0 }}>Status: <strong style={{ color: getStatusColor(order.OrderStatus) }}>{order.OrderStatus}</strong></p>
                            </div>
                            <p style={{ marginBottom: '15px' }}>Shipping Address: {order.ShippingAddress || 'N/A'}</p>

                            <h4>Items:</h4>
                            <ul style={{ listStyle: 'none', padding: 0, borderTop: '1px dashed #eee', paddingTop: '10px' }}>
                                {/*
                                    CRITICAL FIX HERE:
                                    Use optional chaining `order.Items?.map` to prevent errors if `Items` is null or undefined.
                                    Also added nullish coalescing `?? []` as a fallback to ensure `map` is called on an array.
                                    Ensured consistent casing for backend properties (e.g., OrderId, TotalAmount, OrderStatus, ShippingAddress, Items, etc.)
                                    based on typical .NET conventions. You MUST verify these against your actual backend response.
                                */}
                                {order.Items?.map(item => {
                                    const unitPrice = Number(item.UnitPriceAtOrder ?? 0);
                                    const discount = Number(item.DiscountAppliedAtOrder ?? 0);
                                    const effectivePrice = unitPrice - (unitPrice * discount / 100);
                                    const displayItemPrice = isNaN(effectivePrice) ? 'N/A' : effectivePrice.toFixed(2);

                                    return (
                                        <li key={item.ProductId} style={{ display: 'flex', alignItems: 'center', marginBottom: '10px', padding: '5px 0', borderBottom: '1px dashed #f0f0f0' }}>
                                            {/* Assuming ProductId is the unique key for items */}
                                            <img
                                                src={`${BASE_URL}${item.ImageUrl?.startsWith('/') ? item.ImageUrl : `/images/${item.ImageUrl ?? ''}`}`}
                                                alt={item.ProductName || 'Product Image'}
                                                style={{ width: '40px', height: '40px', objectFit: 'cover', borderRadius: '5px', marginRight: '10px'}}
                                            />
                                            <span>
                                                {item.ProductName || 'Unknown Product'} (x{item.Quantity ?? 0}) - ₹{displayItemPrice} each
                                                {discount > 0 && <span style={{ fontSize: '0.8em', color: '#888' }}> ({discount}% off)</span>}
                                            </span>
                                        </li>
                                    );
                                }) ?? <p style={{ textAlign: 'center', color: '#999' }}>No items found for this order.</p>}
                            </ul>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default OrderHistoryPage;