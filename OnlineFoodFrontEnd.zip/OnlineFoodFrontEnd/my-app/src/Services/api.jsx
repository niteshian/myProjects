import axios from 'axios';

const api = axios.create({
  baseURL: 'https://localhost:7193/api',  // Use your correct backend URL here
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,  // Set timeout to 10 seconds (or more if needed)
});

export default api;
