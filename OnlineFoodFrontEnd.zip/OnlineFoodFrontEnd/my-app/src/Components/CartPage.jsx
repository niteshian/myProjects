import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { CartContext } from '../context/CartContext.jsx'; // Correct path to CartContext

const CartPage = () => {
    // Destructure the cart state and functions from CartContext
    const { cart, removeFromCart, updateQuantity, clearCart } = useContext(CartContext);
    const navigate = useNavigate();

    // Base URL for product images (assuming it's the same as your backend)
    const BASE_URL = 'https://localhost:7193';

    // Helper function to calculate price after discount
    const calculateItemPriceAfterDiscount = (item) => {
        if (item.discount > 0) {
            return item.price - (item.price * item.discount / 100);
        }
        return item.price;
    };

    // Calculate the total amount of all items in the cart
    const calculateCartTotal = () => {
        return cart.reduce((total, item) => {
            const finalPrice = calculateItemPriceAfterDiscount(item);
            return total + (finalPrice * item.quantity);
        }, 0);
    };

    // If the cart is empty, display a message
    if (cart.length === 0) {
        return (
            <div className="container mt-5 text-center">
                <h2 className="mb-3">Your Shopping Cart</h2>
                <p className="lead">Your cart is empty. Start adding some delicious food!</p>
                <button className="btn btn-primary" onClick={() => navigate('/customer-dashboard')}>
                    Continue Shopping
                </button>
            </div>
        );
    }

    // If the cart has items, display them
    return (
        <div className="container mt-4">
            <h2 className="mb-4">Your Shopping Cart</h2>

            <table className="table table-bordered table-hover align-middle">
                <thead className="table-light">
                    <tr>
                        <th scope="col">Product</th>
                        <th scope="col" className="text-end">Price</th>
                        <th scope="col" className="text-center">Quantity</th>
                        <th scope="col" className="text-end">Total</th>
                        <th scope="col" className="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {cart.map((item) => (
                        <tr key={item.productId}>
                            <td>
                                <div className="d-flex align-items-center">
                                    <img
                                        src={`${BASE_URL}${item.imageUrl.startsWith('/images/') ? item.imageUrl : `/images/${item.imageUrl}`}`}
                                        alt={item.productName}
                                        className="img-thumbnail me-3"
                                        style={{ width: '80px', height: '80px', objectFit: 'cover' }}
                                        onError={(e) => { e.target.onerror = null; e.target.src = '/images/default-product.png'; }} // Fallback image
                                    />
                                    <div>
                                        <strong>{item.productName}</strong>
                                        {item.offer && <div className="text-success small">{item.offer}</div>}
                                        {item.discount > 0 && <div className="text-warning small">{item.discount}% off</div>}
                                    </div>
                                </div>
                            </td>
                            <td className="text-end">₹{item.price.toFixed(2)}</td>
                            <td className="text-center">
                                <div className="input-group input-group-sm d-inline-flex" style={{ width: '120px' }}>
                                    <button
                                        className="btn btn-outline-secondary"
                                        type="button"
                                        onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                                        disabled={item.quantity <= 1} // Disable decrement if quantity is 1
                                    >
                                        -
                                    </button>
                                    <input
                                        type="number"
                                        className="form-control text-center"
                                        value={item.quantity}
                                        onChange={(e) => updateQuantity(item.productId, parseInt(e.target.value))}
                                        min="1"
                                    />
                                    <button
                                        className="btn btn-outline-secondary"
                                        type="button"
                                        onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                                    >
                                        +
                                    </button>
                                </div>
                            </td>
                            <td className="text-end">₹{(calculateItemPriceAfterDiscount(item) * item.quantity).toFixed(2)}</td>
                            <td className="text-center">
                                <button
                                    className="btn btn-danger btn-sm"
                                    onClick={() => removeFromCart(item.productId)}
                                >
                                    Remove
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
                <tfoot>
                    <tr>
                        <td colSpan="3" className="text-end"><strong>Grand Total:</strong></td>
                        <td colSpan="2" className="text-end"><strong>₹{calculateCartTotal().toFixed(2)}</strong></td>
                    </tr>
                </tfoot>
            </table>

            <div className="d-flex justify-content-between mt-4">
                <button className="btn btn-warning" onClick={clearCart}>
                    Clear Cart
                </button>
                <button className="btn btn-success" onClick={() => navigate('/checkout')}>
                    Proceed to Checkout
                </button>
            </div>
        </div>
    );
};

export default CartPage;