﻿using Microsoft.AspNetCore.Mvc;
using OnlineFood.Data;
using OnlineFood.Dtos;
using Microsoft.IdentityModel.Tokens; // For SecurityTokenDescriptor, SymmetricSecurityKey, etc.
using System.IdentityModel.Tokens.Jwt; // For JwtSecurityTokenHandler
using System.Security.Claims; // For ClaimsIdentity, Claim, ClaimTypes
using System.Text; // For Encoding.ASCII.GetBytes
using Microsoft.Extensions.Configuration; // To access appsettings.json for the secret key
// ... (keep your existing usings)

[Route("api/[controller]")]
[ApiController]
public class AuthController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<AuthController> _logger;
    private readonly IConfiguration _configuration;

    public AuthController(ApplicationDbContext context, ILogger<AuthController> logger, IConfiguration configuration)
    {
        _context = context;
        _logger = logger;
        _configuration = configuration;
    }

    [HttpPost("register")]
    public IActionResult Register([FromBody] RegisterDto registerDto)
    {
        _logger.LogInformation("➡️ Register API called at: {Time}", DateTime.Now);

        try
        {
            _logger.LogInformation("Received registration data: {@RegisterDto}", registerDto);

            if (_context.Users.Any(u => u.Email == registerDto.Email))
            {
                _logger.LogWarning("❗ Duplicate email attempt: {Email}", registerDto.Email);
                return BadRequest(new { message = "Email is already taken." });
            }

            var user = new User
            {
                Name = registerDto.Name,
                Username = registerDto.Username,
                Email = registerDto.Email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(registerDto.Password),
                Role = registerDto.Role
            };

            try
            {
                _context.Users.Add(user);
                _context.SaveChanges();
            }
            catch (Exception dbEx)
            {
                _logger.LogError(dbEx, "❌ Error while saving user to DB");
                return StatusCode(500, new { message = "Database error during registration." });
            }

            _logger.LogInformation("✅ User registered successfully: {@User}", user);
            return Ok(new { message = "Registration successful!" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Registration failed for: {@RegisterDto}", registerDto);
            return StatusCode(500, new { message = "An error occurred during registration." });
        }
    }

    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginDto input)
    {
        _logger.LogInformation("➡️ Login API hit for username: {Username} with role: {Role}", input.Username, input.Role);

        var user = _context.Users.FirstOrDefault(u => u.Username == input.Username);

        if (user == null || !BCrypt.Net.BCrypt.Verify(input.Password, user.PasswordHash))
        {
            _logger.LogWarning("❌ Invalid credentials for: {Username}", input.Username);
            return Unauthorized(new { message = "Invalid username or password." });
        }

        if (!string.Equals(user.Role, input.Role, StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogWarning("❌ Role mismatch for: {Username}. Expected: {ExpectedRole}, Got: {ProvidedRole}",
                                user.Username, user.Role, input.Role);
            return Unauthorized(new { message = "Invalid role selected." });
        }

        _logger.LogInformation("✅ Login successful for: {Username}", user.Username);

        // --- START JWT GENERATION LOGIC (REPLACED "fake-jwt-token") ---
        var tokenHandler = new JwtSecurityTokenHandler();

        // Get the secret key from configuration (appsettings.json / appsettings.Development.json)
        var secretKey = _configuration["Jwt:SecretKey"];

        // Defensive check for null/empty secret key
        if (string.IsNullOrEmpty(secretKey))
        {
            _logger.LogError("JWT SecretKey is not configured or is empty in appsettings.json!");
            return StatusCode(500, new { message = "Server configuration error: JWT Secret Key missing or empty." });
        }

        byte[] keyBytes;
        try
        {
            keyBytes = Encoding.ASCII.GetBytes(secretKey);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error converting JWT SecretKey to bytes. SecretKey might be invalid.");
            return StatusCode(500, new { message = "Server configuration error: Invalid JWT Secret Key format." });
        }

        // Define claims for the token payload (user's unique ID, username, role)
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()), // IMPORTANT: Store user's ID as a claim
            new Claim(ClaimTypes.Name, user.Username),
            new Claim(ClaimTypes.Role, user.Role)
            // Add other claims here if your application logic requires them
        };

        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(claims),
            Expires = DateTime.UtcNow.AddDays(7), // Token valid for 7 days (adjust as needed)
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(keyBytes), SecurityAlgorithms.HmacSha256Signature),
            // Optional: Issuer and Audience from configuration
            Issuer = _configuration["Jwt:Issuer"],
            Audience = _configuration["Jwt:Audience"]
        };

        var token = tokenHandler.CreateToken(tokenDescriptor);
        var jwtString = tokenHandler.WriteToken(token);
        // --- END JWT GENERATION LOGIC ---

        return Ok(new
        {
            token = jwtString, // <-- NOW RETURNS THE REAL JWT
            username = user.Username,
            role = user.Role,
            userId = user.Id // Optional: Can also send userId directly if frontend needs it separately
        });
    }

}




