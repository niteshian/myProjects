package com.example.springsecuritydemo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
@GetMapping("/")
public String home() {
	return "welcome to the home Page(Public)!";
	
}
@GetMapping("/public")
public String publicEndpoint(){
	return "This is the public Endpoint";
}
@GetMapping("/secured")
public String securedEndpoint(){
	return "This is the secured Endpoint,You are authenticated";
}
@GetMapping("/user-only")
public String userOnlyEndpoint() {
    return "This endpoint is for users with ROLE_USER!";
}

@GetMapping("/admin-only")
public String adminOnlyEndpoint() {
    return "This endpoint is for users with ROLE_ADMIN!";
}

}
