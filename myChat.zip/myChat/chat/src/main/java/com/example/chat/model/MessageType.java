package com.example.chat.model;

public enum MessageType {
	CHAT,      
    JOIN,       
    LEAVE       
}


