﻿

namespace OnlineFood.Dtos
{
    public class OrderDisplayDto
    {
        public Guid OrderId { get; set; }
        public DateTime OrderDate { get; set; }
        public string ShippingAddress { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }
        public string PaymentMethod { get; set; } = string.Empty;
        public string OrderStatus { get; set; } = string.Empty;
        public List<OrderItemDisplayDto> Items { get; set; } = new List<OrderItemDisplayDto>();
    }
}
