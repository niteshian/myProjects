﻿using System.ComponentModel.DataAnnotations;

namespace OnlineFood.Dtos
{
    
    public class CreateOrderDto
        {
            [Required]
            public string ShippingAddress { get; set; } = string.Empty;

            [Required]
            public string PaymentMethod { get; set; } = string.Empty; // "COD" or "Online"

            [Required]
            public List<CreateOrderItemDto> Items { get; set; } = new List<CreateOrderItemDto>();
        }

        public class CreateOrderItemDto
        {
            [Required]
            public int ProductId { get; set; }

            [Required]
            [Range(1, int.MaxValue, ErrorMessage = "Quantity must be at least 1.")]
            public int Quantity { get; set; }

            // Frontend sends these for convenience, but backend will re-validate/re-calculate
            [Required]
            public decimal UnitPrice { get; set; }

            [Required]
            public decimal DiscountApplied { get; set; }
        }
    }

