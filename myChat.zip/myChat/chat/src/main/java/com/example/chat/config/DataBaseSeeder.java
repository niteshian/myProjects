package com.example.chat.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.example.chat.model.User;
import com.example.chat.repository.UserRepository;

import lombok.RequiredArgsConstructor;
@RequiredArgsConstructor
@Component
public class DataBaseSeeder implements CommandLineRunner {
	private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    @Override
    public void run(String... args) throws Exception {
        if (userRepository.count() == 0) {
            
            User userA = new User();
            userA.setUsername("alice");
            userA.setPassword(passwordEncoder.encode("password"));
            userA.setRole("ROLE_USER");
            
            User userB = new User();
            userB.setUsername("bob");
            userB.setPassword(passwordEncoder.encode("password"));
            userB.setRole("ROLE_USER");

            userRepository.save(userA);
            userRepository.save(userB);
            
            System.out.println("--- 2 users are created: alice/password आणि bob/password ---");
        }
    }
}


