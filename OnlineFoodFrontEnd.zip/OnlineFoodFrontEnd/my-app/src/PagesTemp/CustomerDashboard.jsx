// src/PagesTemp/CustomerDashboard.jsx
import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { CartContext } from '../context/CartContext.jsx'; // Ensure this path is correct

const CustomerDashboard = () => {
    // --- State Management ---
    const [products, setProducts] = useState([]); // Stores the list of products to display
    const [loading, setLoading] = useState(true);   // Indicates if products are currently being fetched
    const [error, setError] = useState(null);       // Stores any error messages during product fetching

    const [searchTerm, setSearchTerm] = useState(''); // State for the food item name search input
    const [categories, setCategories] = useState([]); // Stores the list of available categories
    const [selectedCategory, setSelectedCategory] = useState(''); // Stores the user's selected category name filter

    const [categoryLoading, setCategoryLoading] = useState(true); // Indicates if categories are being fetched
    const [categoryError, setCategoryError] = useState(null);     // Stores any error messages during category fetching

    // --- Global Cart Context Integration ---
    const { addToCart, removeFromCart, updateCartQuantity, cart } = useContext(CartContext);

    // --- Constants & Hooks ---
    const BASE_URL = 'https://localhost:7193'; // Base URL for API calls to your .NET backend
    const navigate = useNavigate(); // Hook for programmatic navigation using React Router

    // --- Data Fetching Logic ---
    /**
     * Fetches food products from the API based on current search term and selected category.
     * This function constructs the API URL dynamically based on the active filters.
     */
    const fetchProducts = async () => {
        try {
            setLoading(true); // Start loading indicator for products
            setError(null);   // Clear any previous product-related error messages

            const params = new URLSearchParams();
            if (searchTerm) {
                // The backend product controller expects 'searchTerm' for product name search
                params.append('searchTerm', searchTerm);
            }
            if (selectedCategory) {
                // Find the category ID based on the selected category name
                // Note: Assuming `category.name` on the category object, as per API response
                const category = categories.find(cat => cat.name === selectedCategory);
                if (category) {
                    // The backend product controller expects 'categoryId' for category filtering
                    params.append('categoryId', category.categoryId);
                }
            }

            // Always call the 'available' endpoint and pass parameters
            const url = `${BASE_URL}/api/Product/available?${params.toString()}`;

            const response = await axios.get(url); // Execute the API GET request

            // *** IMPORTANT FIX: Handle .NET JSON with $values property ***
            if (response.data && Array.isArray(response.data.$values)) {
                setProducts(response.data.$values);
            }
            // Fallback for direct array response (less common with your backend based on previous logs)
            else if (Array.isArray(response.data)) {
                setProducts(response.data);
                console.warn("API /api/Product/available returned a direct array (unexpected format for this API).");
            }
            else {
                // If it's not an array and not an object with a '$values' array,
                // it's an unexpected format.
                console.error("API /api/Product/available did not return an array or expected object format ($values):", response.data);
                setError("Unexpected data format from server for products.");
                setProducts([]); // Ensure products is always an array
            }
        } catch (err) {
            console.error('Error fetching products:', err.response?.data || err.message);
            if (err.response && err.response.status === 404) {
                setError("No products found matching your criteria.");
            } else {
                setError('Failed to load products. Please try again later.');
            }
            setProducts([]); // Clear products array if there's an error or no results
        } finally {
            setLoading(false);
        }
    };

    /**
     * Fetches all available food categories from the API to populate the filter dropdown.
     */
    const fetchCategories = async () => {
        try {
            setCategoryLoading(true);
            setCategoryError(null);
            const response = await axios.get(`${BASE_URL}/api/Category`);

            // *** IMPORTANT FIX: Handle .NET JSON with $values property for categories ***
            if (response.data && Array.isArray(response.data.$values)) {
                setCategories(response.data.$values);
            }
            // Fallback for direct array response (less common with your backend based on previous logs)
            else if (Array.isArray(response.data)) {
                setCategories(response.data);
                console.warn("API /api/Category returned a direct array (unexpected format for this API).");
            }
            else {
                console.error("API /api/Category did not return an array or expected object format ($values):", response.data);
                setCategoryError('Invalid category data received from server.');
                setCategories([]); // Always ensure categories is an array, even empty, on error
            }
        } catch (err) {
            console.error('Error fetching categories:', err.response?.data || err.message);
            setCategoryError('Failed to load categories. Please try again later.');
            setCategories([]); // Crucial: Set to empty array on error to prevent map error
        } finally {
            setCategoryLoading(false);
        }
    };

    // --- Effects ---
    // useEffect hook to fetch initial categories when the component mounts
    useEffect(() => {
        fetchCategories(); // Fetch categories first so they are available for product filtering
    }, []); // Empty dependency array ensures this runs only once on component mount

    // This useEffect will run when categories are fetched or filters change
    useEffect(() => {
        // Only fetch products if categories are loaded (or there was an error loading them,
        // in which case `selectedCategory` will likely be empty or correspond to an invalid ID)
        if (!categoryLoading) {
            fetchProducts();
        }
    }, [searchTerm, selectedCategory, categoryLoading]); // Re-fetch products when filters or category loading state changes


    // --- Utility Functions ---
    /**
     * Calculates the final price of an item after applying any discount.
     * Ensures price and discount are numbers before calculation.
     * @param {object} item - The product item object.
     * @returns {number} The price after discount.
     */
    const calculateItemPriceAfterDiscount = (item) => {
        // Ensure price and discount are numbers, default to 0 if not
        const price = typeof item.Price === 'number' ? item.Price : 0;
        const discount = typeof item.Discount === 'number' ? item.Dscount : 0;

        if (discount > 0) {
            return price - (price * discount / 100);
        }
        return price;
    };

    /**
     * Calculates the total price of all items currently in the cart.
     * Uses the 'cart' state from the CartContext.
     * @returns {number} The total amount of the cart.
     */
    const calculateCartTotal = () => {
        return cart.reduce((total, item) => {
            const finalPrice = calculateItemPriceAfterDiscount(item);
            return total + (finalPrice * item.quantity);
        }, 0);
    };

    /**
     * Event handler for changes in the food name search input field.
     * Updates the searchTerm state.
     */
    const handleSearchChange = (event) => {
        setSearchTerm(event.target.value);
    };

    /**
     * Event handler for changes in the category dropdown.
     * Updates the selectedCategory state (stores the name, not the ID).
     */
    const handleCategoryChange = (event) => {
        setSelectedCategory(event.target.value);
    };

    /**
     * Event handler for the search and filter form submission.
     * Prevents default form submission behavior (page refresh) and triggers product fetching.
     * The useEffect for searchTerm and selectedCategory will handle the actual fetch.
     */
    const handleApplyFilters = (event) => {
        event.preventDefault(); // Stop default form submission
        // fetchProducts() is now triggered by the useEffect when searchTerm or selectedCategory changes
    };

    /**
     * Resets both the food name search term and the selected category,
     * then triggers a refetch of all products (without filters).
     */
    const handleClearFilters = () => {
        setSearchTerm(''); // Clear the food name search input
        setSelectedCategory(''); // Reset category dropdown to "All Categories"
        // fetchProducts() is now triggered by the useEffect when searchTerm or selectedCategory changes
    };

    // --- Render Logic (Early Exits for Loading/Error States) ---
    // Display a global loading message if products are being fetched and nothing is displayed yet
    if (loading && products.length === 0 && !error) {
        return <div style={{ textAlign: 'center', padding: '50px' }}>Loading products...</div>;
    }

    // --- Main Component JSX Structure ---
    return (
        <div className="customer-dashboard" style={{ padding: '20px', maxWidth: '1200px', margin: 'auto' }}>
            <h2>Welcome, Customer!</h2>
            <hr />

            {/* --- Search and Filter Section --- */}
            <div className="search-and-filter-section" style={{ marginBottom: '30px', textAlign: 'center' }}>
                <form onSubmit={handleApplyFilters} style={{ display: 'inline-flex', gap: '10px', alignItems: 'center' }}>
                    {/* Input for searching by Food Name */}
                    <input
                        type="text"
                        placeholder="Search by food name..."
                        value={searchTerm}
                        onChange={handleSearchChange}
                        style={{
                            padding: '10px 15px',
                            borderRadius: '25px',
                            border: '1px solid #ddd',
                            width: '300px',
                            fontSize: '1em'
                        }}
                    />

                    {/* Dropdown for filtering by Category */}
                    {categoryLoading ? (
                        <span style={{ color: '#007bff' }}>Loading categories...</span>
                    ) : categoryError ? (
                        <span style={{ color: 'red' }}>{categoryError}</span>
                    ) : (
                        <select
                            value={selectedCategory}
                            onChange={handleCategoryChange}
                            style={{
                                padding: '10px 15px',
                                borderRadius: '25px',
                                border: '1px solid #ddd',
                                fontSize: '1em'
                            }}
                        >
                            <option value="">All Categories</option> {/* Option to show all products */}
                            {categories && categories.map(category => (
                                <option key={category.CategoryId} value={category.Name}>
                                    {category.Name}
                                </option>
                            ))}
                        </select>
                    )}

                    <button
                        type="submit" // This button triggers the form submission and applies filters
                        style={{
                            padding: '10px 20px',
                            borderRadius: '25px',
                            border: 'none',
                            backgroundColor: '#007bff',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '1em',
                            fontWeight: 'bold'
                        }}
                    >
                        Apply Filters
                    </button>
                    <button
                        type="button" // Important: Use type="button" to prevent this button from submitting the form
                        onClick={handleClearFilters} // Resets filters and re-fetches all products
                        style={{
                            padding: '10px 20px',
                            borderRadius: '25px',
                            border: 'none',
                            backgroundColor: '#6c757d',
                            color: 'white',
                            cursor: 'pointer',
                            fontSize: '1em',
                            fontWeight: 'bold'
                        }}
                    >
                        Clear Filters
                    </button>
                </form>
            </div>
            <hr />

            <h3>Available Products</h3>
            <div
                className="product-list"
                style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
                    gap: '25px',
                    marginTop: '20px'
                }}
            >
                {/* Conditional rendering for products based on error or no results */}
                {error ? ( // Display error message if there was a problem fetching products
                    <p style={{ textAlign: 'center', width: '100%', color: 'red', fontSize: '1.1em' }}>{error}</p>
                ) : products.length === 0 && !loading ? ( // Display no products message only if not loading and products array is empty
                    <p style={{ textAlign: 'center', width: '100%', color: '#666', fontSize: '1.1em' }}>No products available matching your criteria.</p>
                ) : (
                    // Map over the products array and render a card for each product
                    products.map((product) => (
                        <div
                            key={product.ProductId}
                            className="product-card"
                            style={{
                                border: '1px solid #e0e0e0',
                                borderRadius: '10px',
                                padding: '15px',
                                textAlign: 'center',
                                boxShadow: '0 4px 8px rgba(0,0,0,0.05)',
                                backgroundColor: '#fff'
                            }}
                        >
                            <img
                                // Robust imageUrl handling: checks if imageUrl exists, if it starts with /images/, otherwise prepends it, and uses a default fallback
                                src={`${BASE_URL}${product.ImageUrl ? (product.ImageUrl.startsWith('/images/') ? product.ImageUrl : `/images/${product.ImageUrl}`) : '/images/default-product.png'}`}
                                alt={product.ProductName || 'Product Image'} // Added fallback for alt text
                                style={{
                                    width: '100%',
                                    height: '200px',
                                    objectFit: 'cover',
                                    borderRadius: '8px',
                                    marginBottom: '15px'
                                }}
                                onError={(e) => { e.target.onerror = null; e.target.src = '/images/default-product.png'; }} // Fallback on image load error
                            />
                            <h4 style={{ margin: '10px 0', fontSize: '1.2em' }}>{product.ProductName}</h4>
                            {/* Display category name if available, assuming product.category.name */}
                            {product.Category && product.Category.Name && (
                                <p style={{ fontSize: '0.9em', color: '#555' }}>Category: {product.Category.Name}</p>
                            )}
                            <p style={{ fontSize: '1.1em', fontWeight: 'bold', color: '#333' }}>
                                Price: ₹{typeof product.Price === 'number' ? product.Price.toFixed(2) : 'N/A'}
                            </p>
                            {product.Offer && <p style={{ color: '#28a745', fontWeight: 'bold', fontSize: '0.95em' }}>{product.Offer}</p>}
                            {product.Discount > 0 && (
                                <p style={{ color: '#ffc107', fontSize: '0.9em' }}>
                                    Discount: {product.Discount}% (Final Price: ₹{
                                        // Only attempt toFixed if the result of calculation is a number
                                        typeof calculateItemPriceAfterDiscount(product) === 'number'
                                            ? calculateItemPriceAfterDiscount(product).toFixed(2)
                                            : 'N/A'
                                    })
                                </p>
                            )}
                            <p style={{ color: product.isAvailable ? '#28a745' : '#dc3545', fontWeight: 'bold' }}>
                                Status: {product.IsAvailable ? 'Available' : 'Unavailable'}
                            </p>

                            {product.IsAvailable ? (
                                <div style={{ marginTop: '15px' }}>
                                    {/* Input for quantity */}
                                    <input
                                        type="number"
                                        min="1"
                                        defaultValue="1" // Sets initial value, but user can change it
                                        style={{
                                            width: '70px',
                                            padding: '8px',
                                            borderRadius: '5px',
                                            border: '1px solid #ccc',
                                            marginRight: '10px',
                                            textAlign: 'center'
                                        }}
                                        id={`quantity-${product.ProductId}`} // Unique ID for each quantity input
                                    />
                                    <button
                                        onClick={() => {
                                            const quantityInput = document.getElementById(`quantity-${product.ProductId}`);
                                            const quantity = parseInt(quantityInput.value, 10);
                                            if (quantity > 0) {
                                                // Call the global addToCart function from CartContext
                                                addToCart(product, quantity);
                                                alert(`${quantity} x ${product.ProductName} added to cart!`);
                                                // Optional: navigate('/cart'); // Uncomment if you want to redirect to cart immediately
                                            } else {
                                                alert("Quantity must be at least 1.");
                                            }
                                        }}
                                        style={{
                                            padding: '8px 15px',
                                            backgroundColor: '#007bff',
                                            color: 'white',
                                            border: 'none',
                                            borderRadius: '5px',
                                            cursor: 'pointer'
                                        }}
                                    >
                                        Add to Cart
                                    </button>
                                </div>
                            ) : (
                                <p style={{ color: '#dc3545', marginTop: '15px' }}>Currently Out of Stock</p>
                            )}
                        </div>
                    ))
                )}
            </div>

            <hr />

            {/* --- Shopping Cart Summary Section --- */}
            <div
                className="cart-summary"
                style={{
                    marginTop: '40px',
                    border: '1px solid #e0e0e0',
                    borderRadius: '10px',
                    padding: '20px',
                    backgroundColor: '#f9f9f9',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.05)'
                }}
            >
                <h3>Your Shopping Cart ({cart.length} items)</h3>
                {cart.length === 0 ? (
                    // Display message if the cart is empty
                    <p style={{ textAlign: 'center', padding: '20px', color: '#666' }}>Your cart is empty. Start adding some delicious food!</p>
                ) : (
                    <div>
                        <ul style={{ listStyle: 'none', padding: 0 }}>
                            {cart.map((item) => ( // Iterate over items in the global cart context
                                <li
                                    key={item.ProductId}
                                    style={{
                                        display: 'flex',
                                        justifyContent: 'space-between',
                                        alignItems: 'center',
                                        padding: '10px 0',
                                        borderBottom: '1px dashed #eee'
                                    }}
                                >
                                    <div style={{ display: 'flex', alignItems: 'center' }}>
                                        <img
                                            src={`${BASE_URL}${item.ImageUrl ? (item.ImageUrl.startsWith('/images/') ? item.ImageUrl : `/images/${item.ImageUrl}`) : '/images/default-product.png'}`}
                                            alt={item.ProductName || 'Product Image'}
                                            style={{ width: '50px', height: '50px', objectFit: 'cover', borderRadius: '5px', marginRight: '10px' }}
                                        />
                                        <span>
                                            <strong>{item.ProductName}</strong> <br />
                                            <small>₹{typeof calculateItemPriceAfterDiscount(item) === 'number' ? calculateItemPriceAfterDiscount(item).toFixed(2) : 'N/A'} each</small>
                                        </span>
                                    </div>
                                    <div style={{ display: 'flex', alignItems: 'center' }}>
                                        {/* Buttons to update quantity and remove item, now correctly calling CartContext functions */}
                                        <button
                                            onClick={() => updateCartQuantity(item.ProductId, item.quantity - 1)}
                                            style={{ padding: '5px 10px', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '3px', cursor: 'pointer' }}
                                        >
                                            -
                                        </button>
                                        <span style={{ margin: '0 10px', fontWeight: 'bold' }}>{item.quantity}</span>
                                        <button
                                            onClick={() => updateCartQuantity(item.ProductId, item.quantity + 1)}
                                            style={{ padding: '5px 10px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '3px', cursor: 'pointer' }}
                                        >
                                            +
                                        </button>
                                        <button
                                            onClick={() => removeFromCart(item.productId)}
                                            style={{ marginLeft: '15px', padding: '5px 10px', backgroundColor: '#6c757d', color: 'white', border: 'none', borderRadius: '3px', cursor: 'pointer' }}
                                        >
                                            Remove
                                        </button>
                                    </div>
                                </li>
                            ))}
                        </ul>
                        <h4 style={{ textAlign: 'right', marginTop: '20px', fontSize: '1.5em', color: '#007bff' }}>
                            Total Amount: ₹{calculateCartTotal().toFixed(2)}
                        </h4>
                        <div style={{ textAlign: 'right', marginTop: '20px' }}>
                            <button
                                onClick={() => navigate('/checkout')} // Navigates to the CheckoutPage
                                style={{
                                    padding: '12px 25px',
                                    backgroundColor: '#28a745',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '8px',
                                    fontSize: '1.2em',
                                    cursor: 'pointer',
                                    fontWeight: 'bold'
                                }}
                            >
                                Proceed to Checkout
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default CustomerDashboard;