﻿using Microsoft.AspNetCore.Mvc;
using OnlineFood.Data;
using OnlineFood.Dtos;
using OnlineFood.Models.YourFoodOrderingSystem.Backend.Models; // Assuming this path is correct for your User/Order/Product models
using System.Security.Claims; // For ClaimTypes
using System; // For Guid
using System.Linq; // For LINQ methods like .Where()
using System.Threading.Tasks; // For async/await
using Microsoft.EntityFrameworkCore; // For .Include()
using Microsoft.AspNetCore.Authorization; // ADD THIS LINE for [Authorize]

namespace OnlineFood.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "customer")] // <-- CRITICAL: UNCOMMENT THIS LINE! This ensures only authenticated customers can access.
    public class OrderController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public OrderController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> PlaceOrder([FromBody] CreateOrderDto orderDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // --- Extract CustomerId from the authenticated user's token as a GUID ---
            var customerIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            // Check if the claim is present and can be parsed as a GUID
            if (string.IsNullOrEmpty(customerIdClaim) || !Guid.TryParse(customerIdClaim, out Guid customerId))
            {
                // This error will now be triggered if the token is invalid OR
                // if the 'nameid' claim isn't a valid GUID.
                return Unauthorized("Customer ID not found or invalid in authentication token. Please ensure you are logged in.");
            }

            // REMOVED: No need to compare with orderDto.CustomerId, as it's not present/needed for security.
            // The customerId for the order *must* come from the authenticated user's token.

            // --- Order Validation and Calculation (Backend is the source of truth) ---
            var newOrder = new Order
            {
                OrderId = Guid.NewGuid(), // Assuming OrderId is still a Guid
                CustomerId = customerId, // Now correctly uses the authenticated user's GUID ID
                OrderDate = DateTime.UtcNow, // Set default to current UTC time
                ShippingAddress = orderDto.ShippingAddress,
                PaymentMethod = orderDto.PaymentMethod,
                OrderStatus = "Pending" // Initial status
            };

            decimal calculatedTotalAmount = 0;
            var orderItems = new List<OrderItem>();

            foreach (var itemDto in orderDto.Items)
            {
                var product = await _context.Products.FindAsync(itemDto.ProductId);

                // Ensure the product exists and is available
                if (product == null || !product.IsAvailable)
                {
                    return BadRequest($"Product with ID {itemDto.ProductId} is not available or does not exist.");
                }

                // If you track stock, uncomment this:
                // if (product.StockQuantity < itemDto.Quantity)
                // {
                //      return BadRequest($"Insufficient stock for product {product.ProductName}. Available: {product.StockQuantity}");
                // }

                decimal finalPrice = product.Price;
                if (product.Discount > 0)
                {
                    finalPrice = product.Price - (product.Price * product.Discount / 100);
                }

                orderItems.Add(new OrderItem
                {
                    ProductId = product.ProductId,
                    Quantity = itemDto.Quantity,
                    UnitPriceAtOrder = product.Price, // Store actual price from DB
                    DiscountAppliedAtOrder = product.Discount // Store actual discount from DB
                });

                calculatedTotalAmount += finalPrice * itemDto.Quantity;

                // If you track stock: Decrement stock
                // product.StockQuantity -= itemDto.Quantity;
            }

            newOrder.TotalAmount = calculatedTotalAmount;
            newOrder.OrderItems = orderItems;

            await _context.Orders.AddAsync(newOrder);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Order placed successfully!", orderId = newOrder.OrderId });
        }

        // --- NEW METHOD: Get Customer Orders ---
        [HttpGet("customer-orders")] // Example route: /api/order/customer-orders
        [Authorize(Roles = "customer")] // <-- CRITICAL: UNCOMMENT THIS LINE! Ensures only authenticated customers can access.
        public async Task<IActionResult> GetCustomerOrders()
        {
            // --- Extract CustomerId from the authenticated user's token as a GUID ---
            var customerIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(customerIdClaim) || !Guid.TryParse(customerIdClaim, out Guid customerId))
            {
                return Unauthorized("Customer ID not found or invalid in authentication token. Please log in.");
            }

            var orders = await _context.Orders
                .Where(o => o.CustomerId == customerId) // Filters orders by the authenticated customer's GUID ID
                .Include(o => o.OrderItems) // Eager load order items
                                            // .ThenInclude(oi => oi.Product) // Uncomment this line if your OrderItem model has a navigation property to Product, and you want Product details for each item
                .OrderByDescending(o => o.OrderDate)
                .ToListAsync();

            if (orders == null || !orders.Any())
            {
                return Ok(new List<OrderDisplayDto>());
            }

            // Map database models to DTOs for the response
            var orderDtos = new List<OrderDisplayDto>();
            foreach (var order in orders)
            {
                var itemsDto = new List<OrderItemDisplayDto>();
                foreach (var item in order.OrderItems)
                {
                    // Fetch product details for display (e.g., name, image)
                    // Ensure your ApplicationDbContext.Products DbSet is available and `Product` model has ProductName and ImageUrl
                    var product = await _context.Products.FindAsync(item.ProductId);
                    itemsDto.Add(new OrderItemDisplayDto
                    {
                        ProductId = item.ProductId,
                        ProductName = product?.ProductName ?? "Unknown Product", // Handle if product is null
                        ImageUrl = product?.ImageUrl ?? "/images/default-product.png", // Handle if image is null
                        Quantity = item.Quantity,
                        UnitPriceAtOrder = item.UnitPriceAtOrder,
                        DiscountAppliedAtOrder = item.DiscountAppliedAtOrder
                    });
                }

                orderDtos.Add(new OrderDisplayDto
                {
                    OrderId = order.OrderId,
                    OrderDate = order.OrderDate,
                    ShippingAddress = order.ShippingAddress,
                    TotalAmount = order.TotalAmount,
                    PaymentMethod = order.PaymentMethod,
                    OrderStatus = order.OrderStatus,
                    Items = itemsDto
                });
            }

            return Ok(orderDtos);
        }
    }
}