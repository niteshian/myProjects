import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const OrderConfirmationPage = () => {
    // useParams hook extracts parameters from the URL.
    // In our case, the route is defined as "/order-confirmation/:orderId",
    // so `orderId` will be available here.
    const { orderId } = useParams();
    const navigate = useNavigate(); // Hook for programmatic navigation

    return (
        <div style={{
            padding: '40px',
            maxWidth: '600px',
            margin: 'auto',
            textAlign: 'center',
            border: '1px solid #d4edda', // Light green border
            borderRadius: '10px',
            boxShadow: '0 2px 5px rgba(0,123,255,0.1)', // Subtle blue shadow
            backgroundColor: '#e2f0e8' // Light green background
        }}>
            <h2 style={{
                color: '#28a745', // Green color for success
                fontSize: '2.5em',
                marginBottom: '20px'
            }}>Order Placed Successfully!</h2>

            <p style={{
                fontSize: '1.2em',
                color: '#333',
                marginBottom: '15px'
            }}>
                Thank you for your order! Your order has been successfully placed.
            </p>

            {/* Conditionally display orderId if it exists */}
            {orderId && (
                <p style={{
                    fontSize: '1.1em',
                    fontWeight: 'bold',
                    color: '#007bff', // Blue color for order ID
                    marginBottom: '30px'
                }}>
                    Your Order ID is: <span style={{ textDecoration: 'underline' }}>{orderId}</span>
                </p>
            )}

            <div style={{
                display: 'flex',
                justifyContent: 'center',
                gap: '20px' // Space between buttons
            }}>
                <button
                    onClick={() => navigate('/customer-dashboard')} // Navigate back to shopping
                    style={{
                        padding: '12px 25px',
                        backgroundColor: '#007bff', // Blue button
                        color: 'white',
                        border: 'none',
                        borderRadius: '8px',
                        fontSize: '1em',
                        cursor: 'pointer',
                        fontWeight: 'bold',
                        transition: 'background-color 0.2s ease' // Smooth transition on hover
                    }}
                    // Optional: Add hover effect
                    onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#0056b3'}
                    onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#007bff'}
                >
                    Continue Shopping
                </button>

                <button
                    onClick={() => navigate('/order-history')} // Navigate to order history page
                    style={{
                        padding: '12px 25px',
                        backgroundColor: '#6c757d', // Gray button
                        color: 'white',
                        border: 'none',
                        borderRadius: '8px',
                        fontSize: '1em',
                        cursor: 'pointer',
                        fontWeight: 'bold',
                        transition: 'background-color 0.2s ease' // Smooth transition on hover
                    }}
                    // Optional: Add hover effect
                    onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#5a6268'}
                    onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#6c757d'}
                >
                    View My Orders
                </button>
            </div>
        </div>
    );
};

export default OrderConfirmationPage;