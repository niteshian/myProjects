﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineFood.Data;
using OnlineFood.Dtos;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace OnlineFood.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ProductController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Product/available
                [HttpGet("available")]
                public async Task<ActionResult<IEnumerable<Product>>> GetAvailableProducts([FromQuery]
                      int? categoryId = null,
                      [FromQuery] string? searchTerm = null)
                  
                {
                   var productsQuery = _context.Products
                                                .Where(p => p.IsAvailable)
                                                .Include(p => p.Category) // ADD THIS LINE: Eagerly load the Category data
                                                .AsQueryable();
                 if (categoryId.HasValue && categoryId.Value > 0)
                    {
                        productsQuery = productsQuery.Where(p => p.CategoryId == categoryId.Value);
                    }
            if (!string.IsNullOrWhiteSpace(searchTerm))
                    { productsQuery = productsQuery.Where(p => p.ProductName.ToLower().Contains(searchTerm.ToLower()));
                    }
                return await productsQuery.ToListAsync();
        }

        // POST: api/Product
        [HttpPost]
        public async Task<IActionResult> PostProduct([FromForm] ProductCreateDto dto)
        {
            try
            {
                var existingProductWithSameName = await _context.Products
                    .FirstOrDefaultAsync(p => p.ProductName == dto.Name);
                if (dto.ImageFile == null || dto.ImageFile.Length == 0)
                    return BadRequest("Image file is required.");

                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif" };
                var extension = Path.GetExtension(dto.ImageFile.FileName).ToLower();

                if (!allowedExtensions.Contains(extension))
                    return BadRequest("Invalid image format. Allowed: .jpg, .jpeg, .png, .gif");

                var uniqueFileName = $"{Guid.NewGuid()}{extension}";
                var imageDir = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images");
                Directory.CreateDirectory(imageDir); // Ensure folder exists

                var imagePath = Path.Combine(imageDir, uniqueFileName);

                using (var stream = new FileStream(imagePath, FileMode.Create))
                {
                    await dto.ImageFile.CopyToAsync(stream);
                }

                var product = new Product
                {
                    ProductName = dto.Name,
                    Price = dto.Price,
                    Offer = dto.Offer,
                    Discount = dto.Discount,
                    CategoryId = dto.CategoryId,
                    IsAvailable = dto.IsAvailable,
                    ImageUrl = "/images/" + uniqueFileName
                };

                _context.Products.Add(product);
                await _context.SaveChangesAsync();

                return Ok(product);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        // PUT: api/Product/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduct(int id, [FromForm] ProductUpdateDto dto)
        {
            // 1. Find the product to update
            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            // 2. IMPORTANT: Check for duplicate ProductName, excluding the current product being updated
            // This is the crucial validation step you need to add.
            var existingProductWithSameName = await _context.Products
                .FirstOrDefaultAsync(p => p.ProductName == dto.ProductName && p.ProductId != id);

            if (existingProductWithSameName != null)
            {
                // If a different product already has this name, return a BadRequest with a specific error message.
                // This will be caught by your frontend and can display a more helpful error.
                ModelState.AddModelError("ProductName", "A product with this name already exists.");
                return BadRequest(ModelState); // Return 400 Bad Request with validation errors
            }


            // 3. Update product fields
            product.ProductName = dto.ProductName;
            product.Price = dto.Price;
            product.Offer = dto.Offer;
            product.Discount = dto.Discount;
            product.CategoryId = dto.CategoryId;
            product.IsAvailable = dto.IsAvailable;

            // 4. Handle image file update (existing logic, which is fine)
            if (dto.ImageFile != null && dto.ImageFile.Length > 0)
            {
                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" }; // Consider adding .webp
                var extension = Path.GetExtension(dto.ImageFile.FileName).ToLower();

                if (!allowedExtensions.Contains(extension))
                    return BadRequest("Invalid image format. Allowed: .jpg, .jpeg, .png, .gif, .webp"); // Update message

                // Delete old image if exists
                if (!string.IsNullOrEmpty(product.ImageUrl))
                {
                    var oldImagePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", product.ImageUrl.TrimStart('/'));
                    if (System.IO.File.Exists(oldImagePath))
                    {
                        System.IO.File.Delete(oldImagePath);
                    }
                }

                // Save new image
                var uniqueFileName = $"{Guid.NewGuid()}{extension}";
                var imagePath = Path.Combine("wwwroot/images", uniqueFileName);
                Directory.CreateDirectory(Path.GetDirectoryName(imagePath)); // Ensure directory exists

                using (var stream = new FileStream(imagePath, FileMode.Create))
                {
                    await dto.ImageFile.CopyToAsync(stream);
                }

                product.ImageUrl = "/images/" + uniqueFileName;
            }

            // 5. Save changes to the database
            try
            {
                _context.Products.Update(product); // Mark the entity as modified
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Products.Any(e => e.ProductId == id))
                {
                    return NotFound();
                }
                else
                {
                    throw; // Re-throw other concurrency exceptions
                }
            }
            catch (DbUpdateException ex) // Catch potential database errors not caught by uniqueness check
            {
                // Log the exception details for debugging
                Console.WriteLine($"DbUpdateException: {ex.Message}");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
                }
                return StatusCode(500, "An error occurred while saving changes to the database.");
            }


            // 6. Return success response
            return Ok(product);
        }

        // DELETE: api/Product/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            if (!string.IsNullOrEmpty(product.ImageUrl))
            {
                var fullImagePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", product.ImageUrl.TrimStart('/'));
                if (System.IO.File.Exists(fullImagePath))
                {
                    System.IO.File.Delete(fullImagePath);
                }
            }

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // PUT: api/Product/{id}/availability
        [HttpPut("{id}/availability")]
        public async Task<IActionResult> UpdateAvailability(int id, [FromBody] ProductAvailabilityDto dto)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            product.IsAvailable = dto.IsAvailable;

            _context.Products.Update(product);
            await _context.SaveChangesAsync();

            return Ok(product);
        }
    }
}
