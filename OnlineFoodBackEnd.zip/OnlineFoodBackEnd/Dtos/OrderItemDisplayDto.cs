﻿namespace OnlineFood.Dtos
{
    public class OrderItemDisplayDto
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string ImageUrl { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public decimal UnitPriceAtOrder { get; set; }
        public decimal DiscountAppliedAtOrder { get; set; }


    }
}
