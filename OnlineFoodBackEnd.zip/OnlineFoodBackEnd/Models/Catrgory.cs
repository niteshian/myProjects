﻿namespace OnlineFood.Models
{
    
        public class Category
        {
            public int CategoryId { get; set; }
            public string Name { get; set; }

            // Navigation property for products in this category
            public ICollection<Product> Products { get; set; }
        }


    }

