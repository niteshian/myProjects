// src/components/ProductList.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ProductList.css'; // add styles here

const ProductList = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/product/available')
      .then(response => setProducts(response.data))
      .catch(error => console.error('Error fetching products:', error));
  }, []);

  return (
    <div>
      <h2 className="title">Available Products</h2>
      <div className="product-grid">
        {products.map(product => (
          <div key={product.productId} className="product-card">
            <div className="image-container">
              <img src={product.imageUrl} alt={product.productName} />
              {product.discount > 0 && (
                <div className="discount-tag">{product.discount}% OFF</div>
              )}
            </div>
            <div className="product-details">
              <h3>{product.productName}</h3>
              <p>₹ {product.price}</p>
              {product.offer && <p className="offer">{product.offer}</p>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductList;
