using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using Microsoft.IdentityModel.Tokens;
using OnlineFood.Data;
using System.Text;
using System.Text.Json.Serialization; // Required for ReferenceHandler.IgnoreCycles

var builder = WebApplication.CreateBuilder(args);


// 1. Add Logging Configuration
builder.Logging.AddConsole(); // Adds Console logging to output logs to the console
builder.Logging.AddDebug();    // Adds Debug logging for debugging purposes
builder.Logging.SetMinimumLevel(LogLevel.Information);

// THIS IS THE CRUCIAL JSON SERIALIZATION CONFIGURATION BLOCK
builder.Services.AddControllers().AddJsonOptions(options =>
{
    // This is the key line to ignore circular references
    options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
    options.JsonSerializerOptions.WriteIndented = true; // Optional: for human-readable output
    options.JsonSerializerOptions.PropertyNamingPolicy = null; // Optional: if you want exact casing from your C# models (e.g., ProductName instead of productName)
});



// 2. Add CORS policy
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend",
        policy =>
        {
            policy.WithOrigins("http://localhost:5173") // Replace with your frontend URL
                  .AllowAnyHeader()
                  .AllowAnyMethod()
                  .AllowCredentials();
        });
});

// 3. DB context
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(builder.Configuration.GetConnectionString("DefaultConnection"),
        new MySqlServerVersion(new Version(8, 0, 33))));


// --- START JWT Authentication Configuration (Corrected) ---
// Get JWT settings from appsettings.json
var jwtSecretKey = builder.Configuration["Jwt:SecretKey"];
var jwtIssuer = builder.Configuration["Jwt:Issuer"];
var jwtAudience = builder.Configuration["Jwt:Audience"];

// Defensive check for secret key
if (string.IsNullOrEmpty(jwtSecretKey))
{
    throw new InvalidOperationException("JWT:SecretKey is not configured in appsettings.json.");
}
if (string.IsNullOrEmpty(jwtIssuer))
{
    throw new InvalidOperationException("JWT:Issuer is not configured in appsettings.json.");
}
if (string.IsNullOrEmpty(jwtAudience))
{
    throw new InvalidOperationException("JWT:Audience is not configured in appsettings.json.");
}

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.RequireHttpsMetadata = false; // Set to true in production
        options.SaveToken = true;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecretKey)), // <--- CRITICAL FIX: Provide the secret key

            ValidateIssuer = true, // <--- CRITICAL FIX: Validate the issuer
            ValidIssuer = jwtIssuer, // <--- CRITICAL FIX: Provide the valid issuer

            ValidateAudience = true, // <--- CRITICAL FIX: Validate the audience
            ValidAudience = jwtAudience, // <--- CRITICAL FIX: Provide the valid audience

            ValidateLifetime = true, // Validate token expiration
            ClockSkew = TimeSpan.Zero // No leeway for expiration
        };
    });
// --- END JWT Authentication Configuration (Corrected) ---


// 5. Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();
app.UseStaticFiles();

// 6. Enable Swagger if in dev
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// 7. Use HTTPS redirection
app.UseHttpsRedirection();

// 8. Use CORS here (must be before authentication)
app.UseRouting();
app.UseCors("AllowFrontend");

// 9. Use Authentication and Authorization
app.UseAuthentication();
app.UseAuthorization();    // Add this line to ensure authorization is enabled

// 10. Map controllers
app.MapControllers();

// 11. Endpoint for testing
app.MapGet("/weatherforecast", () =>
{
    var summaries = new[]
    {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

    var forecast = Enumerable.Range(1, 5).Select(index =>
        new WeatherForecast
        (
            DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            Random.Shared.Next(-20, 55),
            summaries[Random.Shared.Next(summaries.Length)]
        ))
        .ToArray();

    return forecast;
})
.WithName("GetWeatherForecast")
.WithOpenApi();

// 12. Run the app
app.Run();

// 13. Record class
record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}