package com.example.chat.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.chat.model.ChatMessage;

public interface ChatMessageRepository extends MongoRepository<ChatMessage, String> {

}
