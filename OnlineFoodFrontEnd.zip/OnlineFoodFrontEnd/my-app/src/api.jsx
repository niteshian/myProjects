// src/api.js
import axios from 'axios';

// Create an Axios instance with your backend API base URL
const api = axios.create({
  baseURL: 'https://localhost:7193/api', // <--- **CRITICAL: Make sure this matches your .NET backend's actual base URL**
  headers: {
    'Content-Type': 'application/json',
  },
});

// Optional: Add a request interceptor to automatically include the auth token
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token'); // Assuming your token is stored under the key 'token'
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, error => {
  return Promise.reject(error);
});

export default api; // This exports the configured Axios instance