import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../Services/api';

function Login() {
    const [formData, setFormData] = useState({
        username: '',
        password: '',
        role: 'customer', // default role in lowercase
    });

    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({ ...prevData, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const res = await api.post('/auth/login', {
                username: formData.username,
                password: formData.password,
                role: formData.role,
            });

            console.log("Backend Login Response Data:", res.data);
            console.log("Role received from backend:", res.data.role); // This is the backend's confirmed role

            const tokenFromBackend = res.data.token || res.data.accessToken || res.data.jwt;
            const backendUserRole = res.data.role; // Capture the role from the backend

            if (tokenFromBackend && backendUserRole) { // Ensure both token and role are present
                localStorage.setItem('token', tokenFromBackend); // <-- CORRECTED: Store as 'token' for PrivateRoute
                localStorage.setItem('role', backendUserRole.toLowerCase()); // <-- CORRECTED: Store backend's role, lowercase
                // You can remove localStorage.setItem('customerToken', ...) if it's no longer needed elsewhere

                console.log('Login successful! Stored Token:', tokenFromBackend);
                console.log('Login successful! Stored Role (lowercase):', backendUserRole.toLowerCase());
                alert('Login successful!'); // You might want to remove this alert for smoother UX

                // --- Use the backend-verified role for navigation ---
                if (backendUserRole.toLowerCase() === 'admin') {
                    console.log('Navigating to admin-dashboard');
                    navigate('/admin-dashboard');
                } else if (backendUserRole.toLowerCase() === 'customer') { // Explicitly check for customer
                    console.log('Navigating to customer-dashboard');
                    navigate('/customer-dashboard');
                } else {
                    // Fallback for unexpected roles, navigate to home or show error
                    console.warn(`Unexpected role '${backendUserRole}' received. Navigating to home.`);
                    navigate('/');
                }
            } else {
                console.error("Login successful, but token or role missing in backend response data.", res.data);
                alert('Login failed: Authentication token or role not received from the server. Please contact support.');
            }

        } catch (err) {
            console.error('Login error:', err.response?.data || err.message);
            alert('Invalid credentials. Please try again.');
        }
    };

    return (
        <div style={formContainerStyles}>
            <h2>Login</h2>
            <form onSubmit={handleSubmit} style={formStyles}>
                <div style={inputGroupStyles}>
                    <label htmlFor="username">Username</label>
                    <input
                        type="text"
                        id="username"
                        name="username"
                        value={formData.username}
                        onChange={handleChange}
                        placeholder="Enter your username"
                        style={inputStyles}
                        required
                    />
                </div>

                <div style={inputGroupStyles}>
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        placeholder="Enter your password"
                        style={inputStyles}
                        required
                    />
                </div>

                <div style={inputGroupStyles}>
                    <label htmlFor="role">Role</label>
                    <select
                        id="role"
                        name="role"
                        value={formData.role}
                        onChange={handleChange}
                        style={inputStyles}
                        required
                    >
                        <option value="customer">Customer</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>

                <button type="submit" style={submitButtonStyles}>
                    Login
                </button>
            </form>
        </div>
    );
}

// Styling (keeping your styles here)
const formContainerStyles = {
    width: '300px',
    margin: '0 auto',
    padding: '20px',
    backgroundColor: '#f9f9f9',
    borderRadius: '8px',
};

const formStyles = {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px',
};

const inputGroupStyles = {
    display: 'flex',
    flexDirection: 'column',
};

const inputStyles = {
    padding: '10px',
    marginTop: '5px',
    borderRadius: '4px',
    border: '1px solid #ccc',
};

const submitButtonStyles = {
    padding: '10px',
    backgroundColor: '#007BFF',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
};

export default Login;